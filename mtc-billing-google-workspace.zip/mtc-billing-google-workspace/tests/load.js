/* Loads the mock services and every .gs file into one fresh sandbox, like the Apps Script runtime does. */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

function load() {
  const ctx = { console, Intl, TextEncoder, TextDecoder, Buffer, Date, Math, JSON };
  ctx.globalThis = ctx;
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, 'gas_mock.js'), 'utf8'), ctx, { filename: 'gas_mock.js' });
  const src = path.join(__dirname, '..', 'src');
  const order = ['Config.gs', 'Util.gs', 'Db.gs', 'Billing.gs', 'Payments.gs', 'Pdf.gs', 'Email.gs', 'Api.gs', 'Setup.gs'];
  const all = fs.readdirSync(src).filter(f => f.endsWith('.gs'));
  if (all.sort().join() !== order.slice().sort().join()) throw new Error('Unexpected .gs files: ' + all);
  // Apps Script shares one global scope across files; concatenating reproduces that (const/class included).
  vm.runInContext(order.map(f => fs.readFileSync(path.join(src, f), 'utf8')).join('\n;\n'), ctx, { filename: 'project.gs' });
  return ctx;
}
module.exports = { load };
