/* In-memory stand-ins for the Google Apps Script services the app uses. Works in Node and in a browser. */
(function (G) {
  const enc = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;
  const toB64 = bytes => (typeof Buffer !== 'undefined' ? Buffer.from(bytes).toString('base64') : btoa(String.fromCharCode.apply(null, bytes)));
  const fromB64 = s => (typeof Buffer !== 'undefined' ? Array.from(Buffer.from(s, 'base64')) : Array.from(atob(s), c => c.charCodeAt(0)));

  function cellValue(v) {
    // Like Sheets: a leading apostrophe forces text and is not returned; numeric-looking text becomes a number.
    if (typeof v === 'string') {
      if (v.startsWith("'")) return v.slice(1);
      if (/^=/.test(v)) throw new Error('MOCK: formula written to sheet: ' + v);
      if (/^-?\d+(\.\d+)?$/.test(v)) return Number(v);
      if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return new Date(v + 'T00:00:00+12:00'); // Sheets would turn this into a date
    }
    return v;
  }

  class Range {
    constructor(sh, r, c, nr, nc) { Object.assign(this, { sh, r, c, nr: nr || 1, nc: nc || 1 }); }
    getValues() { const out = []; for (let i = 0; i < this.nr; i++) { const row = []; for (let j = 0; j < this.nc; j++) { const v = (this.sh.data[this.r - 1 + i] || [])[this.c - 1 + j]; row.push(v === undefined ? '' : v); } out.push(row); } return out; }
    setValues(vals) { vals.forEach((row, i) => row.forEach((v, j) => this.sh.set(this.r + i, this.c + j, cellValue(v)))); return this; }
    setValue(v) { this.sh.set(this.r, this.c, cellValue(v)); return this; }
    setNumberFormat() { return this; } setFontWeight() { return this; } setBackground() { return this; }
  }
  class Sheet {
    constructor(name) { this.name = name; this.data = []; this.maxRows = 1000; }
    set(r, c, v) { while (this.data.length < r) this.data.push([]); const row = this.data[r - 1]; while (row.length < c) row.push(''); row[c - 1] = v; }
    getName() { return this.name; }
    getLastRow() { let n = this.data.length; while (n > 0 && this.data[n - 1].every(v => v === '' || v === undefined)) n--; return n; }
    getLastColumn() { return this.data.reduce((m, r) => Math.max(m, r.length), 0); }
    getMaxRows() { return Math.max(this.maxRows, this.data.length); }
    getDataRange() { return new Range(this, 1, 1, Math.max(this.getLastRow(), 1), Math.max(this.getLastColumn(), 1)); }
    getRange(r, c, nr, nc) { return new Range(this, r, c, nr, nc); }
    appendRow(arr) { const r = this.getLastRow() + 1; arr.forEach((v, j) => this.set(r, j + 1, cellValue(v))); return this; }
    deleteRow(r) { this.data.splice(r - 1, 1); }
    clearContents() { this.data = []; return this; }
    setFrozenRows() { return this; }
    getProtections() { return this.prot ? [this.prot] : []; }
    protect() { const p = this.prot = { warningOnly: false, setDescription() { return p; }, setWarningOnly(v) { p.warningOnly = v; return p; } }; return p; }
    rows() { return this.data; }
  }
  const book = { sheets: {}, tz: '' };
  G.SpreadsheetApp = {
    getActive: () => ({
      getSheetByName: n => book.sheets[n] || null,
      insertSheet: n => (book.sheets[n] = new Sheet(n)),
      getSheets: () => Object.values(book.sheets),
      deleteSheet: s => { delete book.sheets[s.name]; },
      setSpreadsheetTimeZone: tz => { book.tz = tz; },
      getUrl: () => 'https://docs.google.com/spreadsheets/d/MOCK/edit',
      getId: () => 'SHEET',
    }),
    flush: () => {},
    getUi: () => { throw new Error('no UI in tests'); },
    ProtectionType: { SHEET: 'SHEET' },
  };
  G.__book = book;

  G.LockService = { getScriptLock: () => ({ tryLock: () => true, waitLock: () => {}, releaseLock: () => {} }) };
  G.__user = 'owner@mtc.test';
  G.Session = { getActiveUser: () => ({ getEmail: () => G.__user }), getEffectiveUser: () => ({ getEmail: () => 'owner@mtc.test' }) };

  const props = {};
  G.PropertiesService = { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = String(v); } }) };

  function fmt(date, tz, pattern) {
    const p = {};
    new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' })
      .formatToParts(date).forEach(x => { p[x.type] = x.value; });
    return pattern.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute).replace('ss', p.second);
  }
  class Blob {
    constructor(bytes, mime, name) { this.bytes = bytes; this.mime = mime; this.name = name; }
    getBytes() { return this.bytes; } getContentType() { return this.mime; } getName() { return this.name; }
    setName(n) { this.name = n; return this; }
    getDataAsString() { return typeof TextDecoder !== 'undefined' ? new TextDecoder().decode(new Uint8Array(this.bytes)) : String.fromCharCode.apply(null, this.bytes); }
    getAs(mime) {
      // "PDF": keep the HTML's visible text so tests can check what the invoice says.
      const text = this.getDataAsString().replace(/<style[\s\S]*?<\/style>/g, '').replace(/<br>/g, '\n').replace(/<\/(tr|div)>/g, '\n').replace(/<[^>]+>/g, ' ')
        .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#39;/g, "'").replace(/&quot;/g, '"').replace(/[ \t]+/g, ' ');
      const b = new Blob(Array.from(enc ? enc.encode(text) : text, c => (typeof c === 'number' ? c : c.charCodeAt(0))), mime, this.name);
      b.html = this.getDataAsString();
      return b;
    }
  }
  const strBytes = s => Array.from(enc ? enc.encode(s) : s, c => (typeof c === 'number' ? c : c.charCodeAt(0)));
  let uuid = 0;
  G.Utilities = {
    formatDate: fmt,
    base64Encode: (x) => toB64(typeof x === 'string' ? strBytes(x) : x),
    base64Decode: s => fromB64(s),
    newBlob: (data, mime, name) => new Blob(typeof data === 'string' ? strBytes(data) : data, mime, name),
    getUuid: () => 'uuid-' + (++uuid),
    Charset: { UTF_8: 'UTF-8' },
  };
  G.HtmlService = {
    createHtmlOutput: html => ({ content: html || '', getContent() { return this.content; }, getBlob: () => new Blob(strBytes(html || ''), 'text/html', 'x.html'),
      setWidth() { return this; }, setHeight() { return this; }, setTitle(t) { this.title = t; return this; }, addMetaTag() { return this; } }),
    createTemplateFromFile: name => ({ evaluate: () => ({ content: 'APP:' + name, setTitle(t) { this.title = t; return this; }, addMetaTag() { return this; } }) }),
  };

  const drive = { files: {}, folders: {}, n: 0 };
  function folderObj(id) {
    return {
      getId: () => id,
      createFile: blob => { const fid = 'file-' + (++drive.n); drive.files[fid] = { blob, folder: id, created: drive.n }; return { getId: () => fid }; },
      getFiles: () => {
        const list = Object.keys(drive.files).filter(k => drive.files[k].folder === id && !drive.files[k].trashed).map(fileObj);
        return { hasNext: () => list.length > 0, next: () => list.shift() };
      },
    };
  }
  G.DriveApp = {
    createFolder: name => { const id = 'folder-' + (++drive.n); drive.folders[id] = name; return folderObj(id); },
    getFolderById: id => { if (!drive.folders[id]) throw new Error('not found'); return folderObj(id); },
    getFileById: id => {
      if (id === 'SHEET') return { makeCopy: (name, folder) => folder.createFile({ copyOf: 'SHEET', name }) };
      if (!drive.files[id]) throw new Error('File not found');
      return fileObj(id);
    },
  };
  function fileObj(fid) {
    const f = drive.files[fid];
    return { getId: () => fid, getBlob: () => f.blob, getDateCreated: () => new Date(2026, 0, 1, 0, 0, f.created), setTrashed: v => { f.trashed = v; } };
  }
  G.__drive = drive;

  G.__outbox = [];
  G.__mailFail = null;
  G.MailApp = {
    sendEmail: o => { if (G.__mailFail) throw new Error(G.__mailFail); G.__outbox.push(o); },
    getRemainingDailyQuota: () => 1500 - G.__outbox.length,
  };

  const triggers = [];
  G.ScriptApp = {
    getProjectTriggers: () => triggers.slice(),
    deleteTrigger: t => triggers.splice(triggers.indexOf(t), 1),
    newTrigger: fn => {
      const b = { everyHours: () => b, everyWeeks: () => b, create: () => { const t = { getHandlerFunction: () => fn }; triggers.push(t); return t; } };
      return { timeBased: () => b };
    },
    getService: () => ({ getUrl: () => 'https://script.google.com/a/macros/mtc.test/s/MOCK/exec' }),
  };
  G.__triggers = triggers;
})(typeof window !== 'undefined' ? window : globalThis);
