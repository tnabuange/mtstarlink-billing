/* Verification suite. Run:  node tests/run_tests.js */
const assert = require('assert');
const { load } = require('./load');

const tests = [];
const test = (name, fn) => tests.push([name, fn]);

function fresh(today) {
  const g = load();
  g.TEST_TODAY = today || '2026-10-05';
  g.setup();
  const call = (action, args) => {
    const r = g.api(action, args || {});
    if (!r.ok) { const e = new Error(r.error); e.apiError = true; throw e; }
    return r.data;
  };
  const fails = (action, args) => {
    const r = g.api(action, args || {});
    assert.strictEqual(r.ok, false, action + ' should have failed');
    return r.error;
  };
  const rows = name => {
    const sh = g.__book.sheets[name];
    const [head, ...data] = sh.data;
    return data.filter(r => r.some(v => v !== '')).map(r => Object.fromEntries(head.map((h, i) => [h, r[i] === undefined ? '' : r[i]])));
  };
  const cid = code => rows('Customers').find(c => c.code === code).id;
  return { g, call, fails, rows, cid };
}

function configure(t) {
  t.call('saveSettings', {
    company_name: 'MT Creatives Trading', company_address: 'Bairiki, Tarawa', company_phone: '', company_email: 'accounts@mtc.test',
    company_reg: '', bank_account_name: 'MT Creatives Trading', bank_name: 'Test Bank', bank_branch: 'Bairiki', bank_account_number: '000-TEST',
    bank_swift: '', payment_instructions: '', sender_name: 'Test Sender', reply_to: '', invoice_prefix: 'MTC', default_due_days: '30',
    reminder_offsets: '-7, 7, 14',
  });
  const knla = t.cid('KNLA');
  t.call('saveCustomer', { id: knla, code: 'KNLA', billing_name: 'KNLA', school_division: '', location: 'Tarawa', officer_name: 'Test Officer',
    officer_email: 'officer@knla.test', cc_email: 'cc@knla.test', notes: '', active: '1' });
  t.call('saveKit', { customer_id: knla, kit_ref: 'KIT-TEST-1', service_location: 'Main office', plan: 'Standard', billing_start: '2026-07-01',
    billing_end: '', status: 'active', monthly_rate: '100.00', notes: '' });
  return knla;
}

// ======================================================================= required scenario

test('Required scenario: AUD 300 → pay 100 → AUD 200 everywhere → pay 200 → paid, reminders stop, no duplicates', () => {
  const t = fresh();
  const knla = configure(t);

  assert.ok(t.call('dashboard', {}).gaps.includes('12 account(s) have no billing officer email.'));

  // Quarterly drafts for all eligible accounts: only KNLA has a kit.
  let gen = t.call('generate', { mode: 'quarter_all', quarter: '2026-Q3' }).result;
  assert.strictEqual(gen.created.length, 1);
  const invId = gen.created[0].id;
  let inv = t.call('invoice', { id: invId });
  assert.strictEqual(inv.invoice.total_c, 30000);
  assert.deepStrictEqual(inv.lines.map(l => [l.period_start, l.period_end, l.rate_c, l.months, l.amount_c]), [['2026-07-01', '2026-09-30', 10000, '3', 30000]]);

  // Issue → number, due date and PDF in Drive.
  assert.strictEqual(t.call('issue', { ids: String(invId) }).message, 'Issued MTC-2026-0001. The PDF is saved in Google Drive.');
  inv = t.call('invoice', { id: invId }).invoice;
  assert.strictEqual(inv.due_date, '2026-11-04');
  const pdf = t.g.__drive.files[inv.pdf_file_id].blob;
  const pdfText = pdf.getDataAsString();
  for (const s of ['MTC-2026-0001', 'AUD 300.00', 'KNLA', 'Test Bank', '000-TEST', '1 Jul – 30 Sep 2026', '04 Nov 2026', 'Attn: Test Officer'])
    assert.ok(pdfText.includes(s), 'PDF should contain ' + s);
  assert.strictEqual(pdf.getContentType(), 'application/pdf');
  assert.strictEqual(t.call('invoicePdf', { id: invId }).name, 'MTC-2026-0001.pdf');

  // Rerunning generation doesn't duplicate.
  gen = t.call('generate', { mode: 'quarter_all', quarter: '2026-Q3' }).result;
  assert.strictEqual(gen.created.length, 0);
  assert.match(gen.skipped[0].reason, /already exists \(MTC-2026-0001\)/);
  assert.match(t.fails('generate', { mode: 'quarter_one', customer_id: knla, quarter: '2026-Q3' }), /already exists/);
  assert.strictEqual(t.rows('Invoices').length, 1);

  // AUD 100 payment.
  let r = t.call('recordPayment', { customer_id: knla, amount: '100', received_date: '2026-10-05', reference: 'TXN-0001', method: 'bank_transfer', payer: 'MoE', notes: '', apply_mode: 'oldest' });
  assert.strictEqual(r.message, 'Payment of AUD 100.00 recorded.');

  // AUD 200 outstanding on the invoice, the statement and the reminder.
  inv = t.call('invoice', { id: invId }).invoice;
  assert.strictEqual(inv.balance_c, 20000);
  assert.strictEqual(inv.state, 'partial');
  assert.strictEqual(t.call('statement', { id: knla }).statement.closing, 20000);
  const prev = t.call('emailPreview', { id: invId, kind: 'reminder' });
  assert.strictEqual(prev.balance_c, 20000);
  assert.ok(prev.body.includes('The outstanding balance is AUD 200.00'));
  assert.deepStrictEqual([prev.to, prev.cc], [['officer@knla.test'], ['cc@knla.test']]);
  assert.deepStrictEqual(prev.problems, []);

  // The raw data in the sheet.
  assert.deepStrictEqual(t.rows('Invoice balances').filter(x => x.Invoice === 'MTC-2026-0001').map(x => [x.Status, x['Total AUD'], x['Paid AUD'], x['Balance AUD']]), [['Partly paid', 300, 100, 200]]);
  assert.strictEqual(t.rows('Payments')[0].amount_aud, 100);
  assert.strictEqual(t.rows('Payments')[0].reference, 'TXN-0001');

  // Enable automatic reminders → hourly trigger installed.
  const s = t.call('settings').settings;
  t.call('saveSettings', Object.assign({}, s, { reminders_enabled: '1' }));
  assert.deepStrictEqual(JSON.stringify(t.g.__triggers.map(x => x.getHandlerFunction()).sort()), JSON.stringify(['reminderTrigger', 'weeklyBackup']));

  // 7 days after due: the hourly trigger sends one overdue reminder showing AUD 200.
  t.g.TEST_TODAY = '2026-11-11';
  t.g.reminderTrigger();
  assert.strictEqual(t.g.__outbox.length, 1);
  const m = t.g.__outbox[0];
  assert.strictEqual(m.to, 'officer@knla.test');
  assert.strictEqual(m.cc, 'cc@knla.test');
  assert.strictEqual(m.name, 'Test Sender');
  assert.ok(m.body.includes('Dear Test Officer,\nI’m following up on MT Creatives Trading invoice MTC-2026-0001 for Starlink services provided to KNLA during 1 Jul – 30 Sep 2026. The outstanding balance is AUD 200.00, and the invoice was due on 04 Nov 2026. I’ve attached a copy for your reference.'));
  assert.ok(m.body.includes('Could you please let me know when payment is expected?'));
  assert.ok(m.body.endsWith('Thank you,\nTest Sender\nMT Creatives Trading'));
  assert.strictEqual(m.attachments[0].getName(), 'MTC-2026-0001.pdf');

  // Running again sends nothing new.
  t.g.reminderTrigger();
  assert.match(t.call('runReminders').message, /0 sent/);
  assert.strictEqual(t.g.__outbox.length, 1);
  const log = t.rows('EmailLog');
  assert.strictEqual(log.length, 1);
  assert.deepStrictEqual([log[0].status, log[0].stage, log[0].trigger, log[0].to, log[0].cc, log[0].balance_aud], ['sent', 'due+7', 'auto', 'officer@knla.test', 'cc@knla.test', 200]);
  assert.ok(log[0].sent_at);

  // Duplicate-looking payment is caught and nothing is saved.
  r = t.call('recordPayment', { customer_id: knla, amount: '100', received_date: '2026-10-05', reference: 'TXN-0001', method: 'bank_transfer', apply_mode: 'oldest' });
  assert.strictEqual(r.duplicates.length, 1);
  assert.strictEqual(t.rows('Payments').length, 1);

  // The remaining AUD 200.
  r = t.call('recordPayment', { customer_id: knla, amount: '200', received_date: '2026-11-11', reference: 'TXN-0002', method: 'deposit', payer: 'MoE', apply_mode: 'oldest' });
  inv = t.call('invoice', { id: invId });
  assert.strictEqual(inv.invoice.state, 'paid');
  assert.strictEqual(inv.invoice.balance_c, 0);
  assert.strictEqual(inv.next_auto, null);
  assert.strictEqual(t.call('statement', { id: knla }).statement.closing, 0);

  // Reminders stop: at +14 days nothing is sent; manual reminder refused.
  t.g.TEST_TODAY = '2026-11-18';
  t.g.reminderTrigger();
  assert.strictEqual(t.g.__outbox.length, 1);
  assert.match(t.fails('sendEmail', { id: invId, kind: 'reminder' }), /Nothing is outstanding/);

  // Still no duplicate after payment.
  assert.strictEqual(t.call('generate', { mode: 'quarter_all', quarter: '2026-Q3' }).result.created.length, 0);
  assert.strictEqual(t.rows('Invoices').length, 1);

  // Dashboard and CSV.
  const st = t.call('dashboard', { quarter: '2026-Q3' }).stats;
  assert.deepStrictEqual([st.billed_c, st.applied_c, st.outstanding_c, st.overdue_c], [30000, 30000, 0, 0]);
  const csv = Buffer.from(t.call('invoicesCsv', {}).base64, 'base64').toString();
  assert.ok(csv.includes('MTC-2026-0001,KNLA,KNLA,invoice,2026-07-01,2026-09-30,2026-Q3,2026-10-05,2026-11-04,Paid,no,300.00,300.00,0.00,0.00'));
  const pcsv = Buffer.from(t.call('paymentsCsv', {}).base64, 'base64').toString();
  assert.ok(pcsv.includes('TXN-0001') && pcsv.includes('TXN-0002'));
  assert.deepStrictEqual(t.rows('Invoice balances')[0].Status, 'Paid');
});

// ======================================================================= rules

test('Part months, mid-month rate change, review required, adjustment with reason', () => {
  const t = fresh();
  const knla = configure(t);
  const kit = t.rows('Kits')[0].id;
  t.call('addRate', { kit_id: kit, monthly_rate: '124', effective_from: '2026-08-15', note: 'Upgrade' });
  t.call('saveKit', { id: kit, customer_id: knla, kit_ref: 'KIT-TEST-1', service_location: 'Main office', plan: 'Standard', billing_start: '2026-07-01', billing_end: '2026-09-20', status: 'active', notes: '' });
  const id = t.call('generate', { mode: 'quarter_one', customer_id: knla, quarter: '2026-Q3' }).redirect.split('/').pop();
  const d = t.call('invoice', { id });
  assert.deepStrictEqual(d.lines.map(l => [l.period_start, l.period_end, l.rate_c, l.amount_c, l.is_partial]), [
    ['2026-07-01', '2026-07-31', 10000, 10000, false],
    ['2026-08-01', '2026-08-14', 10000, Math.round(10000 * 14 / 31), true],
    ['2026-08-15', '2026-08-31', 12400, Math.round(12400 * 17 / 31), true],
    ['2026-09-01', '2026-09-20', 12400, Math.round(12400 * 20 / 30), true],
  ]);
  assert.match(t.fails('issue', { ids: id }), /Part month needs review/);
  assert.match(t.fails('reviewLine', { id, line_id: d.lines[1].id, amount: '40.00', reason: '' }), /Give a reason/);
  d.lines.slice(1).forEach(l => t.call('reviewLine', { id, line_id: l.id, amount: (l.amount_c / 100).toFixed(2), reason: '' }));
  assert.match(t.fails('addAdjustment', { id, description: 'x', direction: 'discount', amount: '10', reason: '' }), /reason/);
  t.call('addAdjustment', { id, description: 'Outage credit', direction: 'discount', amount: '10', reason: '3-day outage' });
  t.call('issue', { ids: id });
  assert.strictEqual(t.call('invoice', { id }).invoice.total_c, 10000 + 4516 + 6800 + 8267 - 1000);
  const pdf = t.g.__drive.files[t.call('invoice', { id }).invoice.pdf_file_id].blob.getDataAsString();
  assert.ok(pdf.includes('Reason: 3-day outage') && pdf.includes('14/31 days'));
});

test('Custom-period overlap warning; void & reissue returns payments to credit', () => {
  const t = fresh();
  const knla = configure(t);
  const first = Number(t.call('generate', { mode: 'quarter_one', customer_id: knla, quarter: '2026-Q3' }).redirect.split('/').pop());
  t.call('issue', { ids: first });
  const ov = t.call('generate', { mode: 'custom', customer_id: knla, period_start: '2026-09-01', period_end: '2026-10-31' });
  assert.strictEqual(ov.overlap[0].label, 'MTC-2026-0001');
  assert.strictEqual(t.rows('Invoices').length, 1);
  t.call('recordPayment', { customer_id: knla, amount: '100', received_date: '2026-10-05', reference: 'A1', method: 'bank_transfer', apply_mode: 'oldest' });
  const v = t.call('voidInvoice', { id: first, reason: 'Wrong plan', reissue: '1' });
  assert.match(v.message, /AUD 100.00 of payments moved back/);
  const newId = Number(v.redirect.split('/').pop());
  const nd = t.call('invoice', { id: newId }).invoice;
  assert.deepStrictEqual([nd.status, nd.quarter, nd.replaces_invoice_id, nd.total_c], ['draft', '2026-Q3', first, 30000]);
  assert.strictEqual(t.call('customer', { id: knla }).credit_c, 10000);
  t.call('issue', { ids: newId });
  assert.strictEqual(t.call('invoice', { id: newId }).invoice.number, 'MTC-2026-0002');
  t.call('applyCredit', { customer_id: knla, apply: { [newId]: '100' } });
  assert.strictEqual(t.call('invoice', { id: newId }).invoice.balance_c, 20000);
  assert.strictEqual(t.call('invoice', { id: first }).invoice.state, 'void');
  // The custom period can still be created after confirming the overlap.
  const c = t.call('generate', { mode: 'custom', customer_id: knla, period_start: '2026-10-01', period_end: '2026-10-31', confirm_overlap: '1' });
  assert.ok(c.redirect);
});

test('One payment across two invoices, leftover credit, reversal, audit trail; nothing half-saved on bad input', () => {
  const t = fresh();
  const knla = configure(t);
  const ids = ['2026-Q3', '2026-Q4'].map(q => Number(t.call('generate', { mode: 'quarter_one', customer_id: knla, quarter: q }).redirect.split('/').pop()));
  t.call('issue', { 'ids': ids.map(String) });
  // Over-applying to one invoice is refused and nothing is written.
  assert.match(t.fails('recordPayment', { customer_id: knla, amount: '650', received_date: '2026-10-05', reference: 'BIG', method: 'bank_transfer', apply_mode: 'manual', allocations: { [ids[0]]: '400' } }), /more than the balance/);
  assert.strictEqual(t.rows('Payments').length, 0);
  const r = t.call('recordPayment', { customer_id: knla, amount: '650', received_date: '2026-10-05', reference: 'BIG', method: 'bank_transfer', apply_mode: 'oldest' });
  const pid = Number(r.redirect.split('/').pop());
  assert.match(r.message, /AUD 50.00 is held as credit/);
  assert.deepStrictEqual(ids.map(i => t.call('invoice', { id: i }).invoice.state), ['paid', 'paid']);
  t.call('reversePayment', { id: pid, reason: 'Bounced' });
  assert.deepStrictEqual(ids.map(i => t.call('invoice', { id: i }).invoice.state), ['unpaid', 'unpaid']);
  assert.strictEqual(t.call('customer', { id: knla }).credit_c, 0);
  const h = t.call('payment', { id: pid }).history;
  assert.ok(h.some(x => x.action === 'reversed' && x.user === 'owner@mtc.test' && x.detail === 'Bounced'));
});

test('Reminders: off by default, skip paused accounts, failed send is logged and retried', () => {
  const t = fresh();
  const knla = configure(t);
  const id = Number(t.call('generate', { mode: 'quarter_one', customer_id: knla, quarter: '2026-Q3' }).redirect.split('/').pop());
  t.call('issue', { ids: id });
  t.g.TEST_TODAY = '2026-11-11';
  t.g.reminderTrigger();
  assert.strictEqual(t.g.__outbox.length, 0);
  assert.match(t.fails('runReminders'), /off/);
  const s = t.call('settings').settings;
  t.call('saveSettings', Object.assign({}, s, { reminders_enabled: '1' }));
  t.call('saveCustomer', Object.assign(t.call('customer', { id: knla }).customer, { reminders_paused: '1', active: '1' }));
  assert.match(t.call('runReminders').message, /0 sent, 1 skipped/);
  t.call('saveCustomer', Object.assign(t.call('customer', { id: knla }).customer, { reminders_paused: '', active: '1' }));
  t.g.__mailFail = 'Service invoked too many times for one day: email.';
  assert.match(t.call('runReminders').message, /0 sent, 0 skipped, 1 failed/);
  assert.strictEqual(t.rows('EmailLog')[0].status, 'failed');
  assert.match(t.rows('EmailLog')[0].error, /too many times/);
  t.g.__mailFail = null;
  assert.match(t.call('runReminders').message, /1 sent/);
  // Turning reminders off removes the trigger.
  t.call('saveSettings', Object.assign({}, t.call('settings').settings, { reminders_enabled: '' }));
  assert.deepStrictEqual(JSON.stringify(t.g.__triggers.map(x => x.getHandlerFunction())), JSON.stringify(['weeklyBackup']));
});

test('Enabling reminders without a sender name keeps them off', () => {
  const t = fresh();
  const r = t.call('saveSettings', Object.assign({}, t.call('settings').settings, { reminders_enabled: '1', sender_name: '' }));
  assert.match(r.warnings[0], /stay off/);
  assert.deepStrictEqual(JSON.stringify(t.g.__triggers.map(x => x.getHandlerFunction())), JSON.stringify(['weeklyBackup']));
});

test('Only people on the Staff tab get in; proof files go to a private Drive folder', () => {
  const t = fresh();
  const knla = configure(t);
  t.g.__user = 'stranger@mtc.test';
  assert.match(t.g.api('dashboard', {}).error, /not on the Staff list/);
  assert.match(t.g.doGet().content, /don’t have access/);
  assert.strictEqual(t.g.api('invoicePdf', { id: 1 }).ok, false);
  t.g.__user = '';
  assert.strictEqual(t.g.api('customers', {}).ok, false);
  t.g.__user = 'owner@mtc.test';
  assert.strictEqual(t.g.doGet().content, 'APP:Index');
  const r = t.call('recordPayment', { customer_id: knla, amount: '10', received_date: '2026-10-05', reference: 'P', method: 'other', apply_mode: 'credit',
    proof: { name: 'receipt.pdf', mime: 'application/pdf', base64: Buffer.from('%PDF-1.4 test').toString('base64') } });
  const p = t.rows('Payments')[0];
  const f = t.g.__drive.files[p.proof_file_id];
  assert.strictEqual(t.g.__drive.folders[f.folder], 'MTC Billing – Payment evidence (private)');
  assert.strictEqual(Buffer.from(t.call('proof', { id: p.id }).base64, 'base64').toString(), '%PDF-1.4 test');
  assert.match(t.fails('recordPayment', { customer_id: knla, amount: '10', received_date: '2026-10-04', reference: 'Q', method: 'other', apply_mode: 'credit',
    proof: { name: 'virus.exe', base64: 'AAAA' } }), /PDF or an image/);
  assert.ok(r.redirect);
});

test('Sheet keeps text exactly: leading zeros, dates, and no formulas from typed text', () => {
  const t = fresh();
  const knla = configure(t);
  t.call('saveCustomer', Object.assign(t.call('customer', { id: knla }).customer, { notes: '=HYPERLINK("http://evil")', active: '1' }));
  t.call('recordPayment', { customer_id: knla, amount: '5', received_date: '2026-10-01', reference: '000123', method: 'other', apply_mode: 'credit', payer: '+686 1234' });
  const p = t.rows('Payments')[0];
  assert.strictEqual(p.reference, '000123');
  assert.strictEqual(p.payer, '+686 1234');
  assert.strictEqual(p.received_date, '2026-10-01');
  assert.strictEqual(t.call('customer', { id: knla }).customer.notes, '=HYPERLINK("http://evil")');
  assert.strictEqual(t.rows('Kits')[0].billing_start, '2026-07-01');
});

test('Edits made directly in the sheet are picked up (e.g. a kit date typed as a real date)', () => {
  const t = fresh();
  const knla = configure(t);
  const kits = t.g.__book.sheets.Kits;
  const col = kits.data[0].indexOf('billing_start');
  kits.data[1][col] = new Date('2026-08-01T00:00:00+12:00'); // what Sheets stores when someone types 01/08/2026
  const id = t.call('generate', { mode: 'quarter_one', customer_id: knla, quarter: '2026-Q3' }).redirect.split('/').pop();
  assert.strictEqual(t.call('invoice', { id }).invoice.total_c, 20000);
});

test('Starter accounts, setup is safe to rerun, opening balance', () => {
  const t = fresh();
  assert.deepStrictEqual(t.rows('Customers').map(c => c.billing_name), ['KNLA', 'CDRC', 'EAU', 'KTC', 'KGV & EBS', 'Teabike College', 'LPSSS',
    'Marakei JSS', 'Tamana JSS', 'Nikunau JSS', 'Onotoa JSS', 'Banaba JSS', 'Butaritari JSS']);
  t.call('saveCustomer', Object.assign(t.call('customer', { id: t.cid('KNLA') }).customer, { code: 'KNLA-HQ', active: '1' }));
  t.g.setup();
  assert.strictEqual(t.rows('Customers').length, 13);
  assert.strictEqual(t.rows('Staff').length, 1);
  assert.strictEqual(t.rows('Settings').filter(s => s.key === 'company_name').length, 1);
  const knla = t.cid('KNLA-HQ');
  t.call('setOpening', { customer_id: knla, amount: '450', as_of: '2026-06-30' });
  assert.strictEqual(t.call('statement', { id: knla }).statement.closing, 45000);
  t.call('recordPayment', { customer_id: knla, amount: '450', received_date: '2026-10-01', reference: 'OB', method: 'other', apply_mode: 'oldest' });
  assert.strictEqual(t.call('statement', { id: knla }).statement.closing, 0);
});

test('Managed tabs warn before hand edits; weekly backups keep the latest 12', () => {
  const t = fresh();
  ['Invoices', 'Payments', 'Allocations', 'Audit'].forEach(n => assert.strictEqual(t.g.__book.sheets[n].prot.warningOnly, true, n));
  ['Customers', 'Kits', 'Rates', 'Settings', 'Staff'].forEach(n => assert.ok(!t.g.__book.sheets[n].prot, n));
  t.g.setup();
  assert.strictEqual(t.g.__triggers.filter(x => x.getHandlerFunction() === 'weeklyBackup').length, 1);
  for (let i = 0; i < 14; i++) t.g.weeklyBackup();
  const d = t.g.__drive;
  const live = Object.values(d.files).filter(f => f.blob && f.blob.copyOf === 'SHEET' && !f.trashed);
  assert.strictEqual(live.length, 12);
  assert.strictEqual(d.folders[live[0].folder], 'MTC Billing – Backups');
});

test('Every read action used by the pages works', () => {
  const t = fresh();
  const knla = configure(t);
  t.call('generate', { mode: 'quarter_all', quarter: '2026-Q4' });
  ['bootstrap', 'dashboard', 'customers', 'invoices', 'generateForm', 'payments', 'paymentForm', 'followups', 'emails', 'settings', 'history']
    .forEach(a => t.call(a, {}));
  t.call('customer', { id: knla }); t.call('kit', { id: 1 }); t.call('statement', { id: knla, start: '2026-01-01', end: '2026-12-31' });
  t.call('invoice', { id: 1 }); t.call('paymentForm', { customer_id: knla });
});

// ======================================================================= run

let failed = 0;
for (const [name, fn] of tests) {
  try { fn(); console.log('ok    ' + name); } catch (e) { failed++; console.log('FAIL  ' + name + '\n      ' + (e.stack || e).split('\n').slice(0, 4).join('\n      ')); }
}
console.log('\n' + (tests.length - failed) + '/' + tests.length + ' passed');
process.exit(failed ? 1 : 0);
