/* Builds a browser harness: the real page (Index + Styles + App) with the real server code running in a
   separate frame on mock Google services, joined by a google.script.run stand-in. */
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'src'), out = path.join(__dirname, 'harness');
fs.mkdirSync(out, { recursive: true });
const read = f => fs.readFileSync(path.join(src, f), 'utf8');
const order = ['Config.gs', 'Util.gs', 'Db.gs', 'Billing.gs', 'Payments.gs', 'Pdf.gs', 'Email.gs', 'Api.gs', 'Setup.gs'];
const server = '<!doctype html><script>window.TEST_TODAY = "2026-10-05";</script><script src="gas_mock.js"></script><script>\n' +
  order.map(read).join('\n;\n') + '\n</script><script>setup(); window.ready = true;</script>';
fs.writeFileSync(path.join(out, 'server.html'), server);
fs.copyFileSync(path.join(__dirname, 'gas_mock.js'), path.join(out, 'gas_mock.js'));
const shim = `<iframe id="srv" src="server.html" hidden></iframe><script>
const srv = () => document.getElementById('srv').contentWindow;
window.google = { script: { get run() {
  const h = { ok: null, fail: null };
  const r = { withSuccessHandler(f) { h.ok = f; return r; }, withFailureHandler(f) { h.fail = f; return r; },
    api(action, args) {
      const wait = () => srv().ready ? setTimeout(() => {
        try { h.ok(JSON.parse(JSON.stringify(srv().api(action, JSON.parse(JSON.stringify(args)))))); } catch (e) { h.fail(e); }
      }, 30) : setTimeout(wait, 20);
      wait();
    } };
  return r; } } };
</script>`;
let page = read('Index.html').replace("<?!= include('Styles'); ?>", read('Styles.html')).replace("<?!= include('App'); ?>", shim + read('App.html'));
if (/<\?/.test(page)) throw new Error('unreplaced scriptlet');
fs.writeFileSync(path.join(out, 'index.html'), page);
console.log('harness built');
