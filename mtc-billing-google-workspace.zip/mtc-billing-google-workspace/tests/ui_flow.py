from playwright.sync_api import sync_playwright, expect
B = "http://127.0.0.1:8077/index.html"
errors = []
with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1280, "height": 900})
    pg.on("dialog", lambda d: d.accept())
    pg.on("pageerror", lambda e: errors.append(str(e)))
    pg.goto(B)
    expect(pg.locator("h1")).to_have_text("2026-Q4")

    # Settings through the form
    pg.click("text=Settings")
    expect(pg.locator("h1")).to_have_text("Settings")
    for name, val in [("company_address", "Bairiki, Tarawa"), ("company_email", "accounts@mtc.test"), ("bank_account_name", "MT Creatives Trading"),
                      ("bank_name", "Test Bank"), ("bank_branch", "Bairiki"), ("bank_account_number", "000-TEST"), ("sender_name", "Test Sender")]:
        pg.fill(f"[name={name}]", val)
    pg.click("text=Save settings")
    expect(pg.locator(".flash.ok")).to_contain_text("Settings saved")

    # Account + kit
    pg.click("nav >> text=Accounts"); pg.click("text=KNLA"); pg.click("text=Edit account")
    expect(pg.locator("h1")).to_have_text("Edit KNLA")
    pg.fill("[name=officer_name]", "Test Officer"); pg.fill("[name=officer_email]", "officer@knla.test"); pg.fill("[name=cc_email]", "cc@knla.test")
    pg.click("text=Save account")
    expect(pg.locator(".flash.ok")).to_contain_text("Account saved")
    pg.click("text=Add a kit")
    expect(pg.locator("h1")).to_have_text("Add a Starlink kit")
    pg.fill("[name=kit_ref]", "KIT-TEST-1"); pg.fill("[name=plan]", "Standard"); pg.fill("[name=service_location]", "Main office")
    pg.fill("[name=billing_start]", "2026-07-01"); pg.fill("[name=monthly_rate]", "100")
    pg.click("text=Add kit")
    expect(pg.locator(".flash.ok")).to_contain_text("Kit added")

    # Generate Q3 for all, open the draft, issue
    pg.click("nav >> text=Invoices"); pg.click("text=Create invoices")
    pg.locator("form:has(input[value=quarter_all]) select").select_option("2026-Q3")
    pg.click("form:has(input[value=quarter_all]) >> text=Create drafts")
    expect(pg.locator("#gen-result")).to_contain_text("1 draft created")
    pg.click("#gen-result >> text=KNLA")
    expect(pg.locator("h1")).to_contain_text("Draft #1")
    pg.screenshot(path="/tmp/g_draft.png", full_page=True)
    pg.click("text=Approve and issue")
    expect(pg.locator("h1")).to_contain_text("MTC-2026-0001")
    expect(pg.locator("#outstanding")).to_have_text("AUD 300.00")

    # Record AUD 100
    pg.click("text=Record a payment")
    expect(pg.locator("h1")).to_have_text("Record a payment")
    pg.fill("[name=amount]", "100"); pg.fill("[name=reference]", "TXN-0001")
    pg.click("text=Save payment")
    expect(pg.locator(".flash.ok")).to_contain_text("Payment of AUD 100.00 recorded")

    # AUD 200 on invoice, statement, reminder preview
    pg.click("text=MTC-2026-0001")
    expect(pg.locator("#outstanding")).to_have_text("AUD 200.00")
    pg.screenshot(path="/tmp/g_invoice.png", full_page=True)
    pg.click("a >> text=KNLA"); pg.click("text=Statement")
    expect(pg.locator("tr.total")).to_contain_text("Balance due")
    expect(pg.locator("tr.total")).to_contain_text("AUD 200.00")
    pg.goto(B + "#/invoice/1/email?kind=reminder")
    expect(pg.locator("#email-balance")).to_have_text("AUD 200.00")
    expect(pg.locator("#email-body")).to_contain_text("The outstanding balance is AUD 200.00")
    pg.screenshot(path="/tmp/g_email.png", full_page=True)
    pg.click("text=Send to 2 recipients")
    expect(pg.locator(".flash.ok")).to_contain_text("Sent to officer@knla.test, cc@knla.test")
    outbox = pg.frame_locator("#srv")  # check mock Gmail received it
    sent = pg.frames[1].evaluate("__outbox.map(m => [m.to, m.cc, m.attachments[0].getName(), m.body.includes('AUD 200.00')])")
    print("OUTBOX", sent)

    # Pay the rest
    pg.click("text=Record a payment")
    expect(pg.locator("h1")).to_have_text("Record a payment")
    pg.fill("[name=amount]", "200"); pg.fill("[name=reference]", "TXN-0002")
    pg.click("text=Save payment")
    expect(pg.locator(".flash.ok")).to_contain_text("AUD 200.00 recorded")
    pg.click("text=MTC-2026-0001")
    expect(pg.locator("h1 .pill.paid")).to_have_text("Paid")
    expect(pg.locator("text=Send reminder")).to_have_count(0)

    pg.goto(B + "#/?quarter=2026-Q3")
    expect(pg.locator(".ledger")).to_contain_text("AUD 300.00")
    pg.screenshot(path="/tmp/g_dash.png", full_page=True)

    m = b.new_page(viewport={"width": 390, "height": 844})
    m.goto(B + "#/settings")
    expect(m.locator("h1")).to_have_text("Settings")
    m.screenshot(path="/tmp/g_mob_settings.png")
    b.close()
print("JS errors:", errors or "none")
print("UI FLOW PASSED")
