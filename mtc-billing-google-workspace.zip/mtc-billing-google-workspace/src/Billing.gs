/** Billing rules: rates, drafts, issue, void, credits, balances, statements. Amounts are integer cents. */

// ================================================================= rates and charges

function kitRates_(kitId) {
  return Db.where('Rates', r => r.kit_id === kitId && isIso_(r.effective_from) && r.monthly_c !== null)
    .map(r => ({ from: r.effective_from, c: r.monthly_c }))
    .sort((a, b) => (a.from < b.from ? -1 : a.from > b.from ? 1 : 0));
}

function rateOn_(rates, day) {
  let cur = null;
  rates.forEach(r => { if (r.from <= day) cur = r.c; });
  return cur;
}

function kitLabel_(kit) {
  return 'Starlink service – ' + kit.kit_ref + (kit.plan ? ' – ' + kit.plan : '') +
    (kit.service_location ? ' (' + kit.service_location + ')' : '');
}

/**
 * Itemised charges for one kit over [ps, pe]. Whole calendar months use the monthly rate in force;
 * part months (mid-month start/end, mid-month rate change) are pro-rated by day and flagged for review.
 * Consecutive whole months at the same rate are combined into one line.
 */
function computeKitLines_(kit, rates, ps, pe) {
  const warnings = [];
  const label = kitLabel_(kit);
  if (kit.status === 'suspended') return { lines: [], warnings: ['Kit ' + kit.kit_ref + ' is suspended and was not billed.'] };
  if (!isIso_(kit.billing_start)) {
    return { lines: [], warnings: ['Kit ' + kit.kit_ref + (kit.billing_start ? ' has a billing start date that isn’t yyyy-mm-dd' : ' has no billing start date') + ', so it was not billed.'] };
  }
  if (kit.billing_end && !isIso_(kit.billing_end)) {
    return { lines: [], warnings: ['Kit ' + kit.kit_ref + ' has a billing end date that isn’t yyyy-mm-dd, so it was not billed.'] };
  }
  const ws = maxIso_(ps, kit.billing_start);
  const we = kit.billing_end ? minIso_(pe, kit.billing_end) : pe;
  if (ws > we) return { lines: [], warnings };

  const segments = [];
  let cursor = ws;
  while (cursor <= we) {
    const mFirst = monthFirst_(cursor), mLast = monthLast_(cursor);
    const segEnd = minIso_(we, mLast);
    const cuts = Array.from(new Set(rates.map(r => r.from).filter(f => f > cursor && f <= segEnd))).sort();
    cuts.push(addDays_(segEnd, 1));
    let a = cursor;
    cuts.forEach(cut => {
      const b = addDays_(cut, -1);
      if (a <= b) segments.push({ a, b, rate: rateOn_(rates, a), full: a === mFirst && b === mLast });
      a = cut;
    });
    cursor = addDays_(segEnd, 1);
  }

  const lines = [];
  segments.forEach(s => {
    if (s.rate === null) warnings.push('Kit ' + kit.kit_ref + ' has no monthly rate for ' + fmtPeriod_(s.a, s.b) + '.');
    if (s.full) {
      const prev = lines[lines.length - 1];
      if (prev && !prev.is_partial && s.rate !== null && prev.rate_c === s.rate && addDays_(prev.period_end, 1) === s.a) {
        prev.period_end = s.b;
        prev.n += 1;
        prev.months = String(prev.n);
        prev.amount_c = s.rate * prev.n;
        return;
      }
      lines.push({ kit_id: kit.id, line_type: 'charge', description: label, period_start: s.a, period_end: s.b,
                   rate_c: s.rate, n: 1, months: '1', amount_c: s.rate || 0, is_partial: false, reviewed: false, reason: '' });
    } else {
      const days = daysBetween_(s.a, s.b) + 1, dim = daysInMonth_(s.a);
      lines.push({ kit_id: kit.id, line_type: 'charge', description: label + ' – part month', period_start: s.a, period_end: s.b,
                   rate_c: s.rate, months: days + '/' + dim + ' days', amount_c: Math.round((s.rate || 0) * days / dim),
                   is_partial: true, reviewed: false, reason: '' });
    }
  });
  return { lines, warnings };
}

function buildChargeLines_(customerId, ps, pe) {
  let lines = [], warnings = [];
  Db.where('Kits', k => k.customer_id === customerId)
    .sort((a, b) => (a.kit_ref < b.kit_ref ? -1 : 1))
    .forEach(kit => {
      const r = computeKitLines_(kit, kitRates_(kit.id), ps, pe);
      lines = lines.concat(r.lines);
      warnings = warnings.concat(r.warnings);
    });
  return { lines, warnings };
}

// ================================================================= balances

function ledger_() {
  const payStatus = {};
  Db.all('Payments').forEach(p => { payStatus[p.id] = p.status; });
  const paid = {}, credited = {};
  Db.all('Allocations').forEach(a => {
    if (a.status === 'active' && payStatus[a.payment_id] === 'active') paid[a.invoice_id] = (paid[a.invoice_id] || 0) + a.amount_c;
  });
  Db.all('Credits').forEach(c => { credited[c.invoice_id] = (credited[c.invoice_id] || 0) + c.amount_c; });
  const customers = {};
  Db.all('Customers').forEach(c => { customers[c.id] = c; });
  return { paid, credited, customers };
}

function invView_(inv, L) {
  L = L || ledger_();
  const c = L.customers[inv.customer_id] || {};
  const v = Object.assign({}, inv);
  delete v._row;
  v.paid_c = L.paid[inv.id] || 0;
  v.credited_c = L.credited[inv.id] || 0;
  v.balance_c = (inv.total_c || 0) - v.paid_c - v.credited_c;
  v.billing_name = c.billing_name || '';
  v.customer_code = c.code || '';
  v.officer_name = c.officer_name || '';
  v.officer_email = c.officer_email || '';
  v.reminders_paused = !!c.reminders_paused;
  if (inv.status === 'draft') { v.state = 'draft'; v.overdue = false; }
  else if (inv.status === 'void') { v.state = 'void'; v.overdue = false; }
  else {
    v.state = v.balance_c <= 0 ? 'paid' : (v.paid_c + v.credited_c > 0 ? 'partial' : 'unpaid');
    v.overdue = v.balance_c > 0 && isIso_(inv.due_date) && inv.due_date < today_();
  }
  v.label = inv.kind === 'opening' ? 'Opening balance' : (inv.number || 'Draft #' + inv.id);
  return v;
}

function getInvoice_(id) { return invView_(Db.must('Invoices', id)); }

function listInvoices_(f) {
  f = f || {};
  const L = ledger_();
  let rows = Db.all('Invoices').map(i => invView_(i, L));
  if (f.customer_id) rows = rows.filter(r => r.customer_id === Number(f.customer_id));
  if (f.quarter) {
    const qb = quarterBounds_(f.quarter);
    rows = rows.filter(r => r.kind === 'invoice' && r.period_start <= qb[1] && r.period_end >= qb[0]);
  }
  if (f.state === 'overdue') rows = rows.filter(r => r.overdue);
  else if (f.state === 'outstanding') rows = rows.filter(r => r.state === 'unpaid' || r.state === 'partial');
  else if (f.state) rows = rows.filter(r => r.state === f.state);
  return rows.sort((a, b) => (a.period_start < b.period_start ? 1 : a.period_start > b.period_start ? -1
    : a.billing_name.localeCompare(b.billing_name) || b.id - a.id));
}

function customerCredit_(customerId) {
  const pays = Db.where('Payments', p => p.customer_id === customerId && p.status === 'active');
  const ids = new Set(pays.map(p => p.id));
  const applied = sum_(Db.where('Allocations', a => a.status === 'active' && ids.has(a.payment_id)), a => a.amount_c);
  return sum_(pays, p => p.amount_c) - applied;
}

function paymentUnapplied_(paymentId) {
  const p = Db.must('Payments', paymentId);
  return p.amount_c - sum_(Db.where('Allocations', a => a.payment_id === p.id && a.status === 'active'), a => a.amount_c);
}

// ================================================================= checks

function companyMissing_(s) {
  const out = [];
  if (!s.company_name) out.push('company name');
  if (!s.company_address && !s.company_email && !s.company_phone) out.push('company contact details (address, phone or email)');
  if (!(s.bank_account_number && s.bank_name) && !s.payment_instructions) out.push('bank details or payment instructions');
  return out;
}

function customerMissingForEmail_(c) {
  const out = [];
  if (!c.officer_name) out.push("billing officer's name");
  if (!c.officer_email) out.push("billing officer's email");
  return out;
}

function issueChecks_(invId) {
  const inv = getInvoice_(invId);
  const cust = Db.must('Customers', inv.customer_id);
  const lines = Db.where('InvoiceLines', l => l.invoice_id === inv.id);
  const s = settings_();
  const blocking = [], warnings = [];
  if (inv.status !== 'draft') blocking.push('Only drafts can be issued.');
  companyMissing_(s).forEach(m => blocking.push('Settings are missing ' + m + '.'));
  if (!cust.billing_name) blocking.push('The account has no billing name.');
  if (!lines.length) blocking.push('The invoice has no charges.');
  lines.forEach(l => {
    if (l.line_type === 'charge' && l.rate_c === null) blocking.push('Missing monthly rate: ' + l.description + ' (' + fmtPeriod_(l.period_start, l.period_end) + ').');
    if (l.is_partial && !l.reviewed) blocking.push('Part month needs review: ' + l.description + ' (' + fmtPeriod_(l.period_start, l.period_end) + ').');
  });
  if (lines.length && inv.total_c <= 0) blocking.push('The total must be more than AUD 0.00.');
  if (inv.due_date && inv.due_date < today_()) warnings.push('The due date is in the past.');
  customerMissingForEmail_(cust).forEach(m => warnings.push('The account is missing the ' + m + '; you won’t be able to email this invoice until it’s added.'));
  return { blocking, warnings };
}

// ================================================================= drafts

function overlapping_(customerId, ps, pe, excludeId) {
  return Db.where('Invoices', i => i.customer_id === customerId && i.status !== 'void' && i.kind === 'invoice' &&
    i.period_start <= pe && i.period_end >= ps && i.id !== excludeId);
}

function writeLines_(invoiceId, lines, startSort) {
  lines.forEach((l, i) => Db.insert('InvoiceLines', {
    invoice_id: invoiceId, kit_id: l.kit_id || null, line_type: l.line_type, description: l.description,
    period_start: l.period_start || '', period_end: l.period_end || '', rate_c: l.rate_c === undefined ? null : l.rate_c,
    months: l.months || '', amount_c: l.amount_c, is_partial: !!l.is_partial, reviewed: !!l.reviewed, reason: l.reason || '',
    sort: (startSort || 0) + i,
  }));
}

function recalcTotal_(invoiceId) {
  const total = sum_(Db.where('InvoiceLines', l => l.invoice_id === invoiceId), l => l.amount_c);
  Db.update('Invoices', invoiceId, { total_c: total });
  return total;
}

function eligibleCustomers_(ps, pe) {
  const ids = new Set(Db.where('Kits', k => k.status !== 'suspended' && (!k.billing_start || k.billing_start <= pe) &&
    (!k.billing_end || k.billing_end >= ps)).map(k => k.customer_id));
  return Db.where('Customers', c => c.active && ids.has(c.id)).sort((a, b) => a.billing_name.localeCompare(b.billing_name));
}

function createDraft_(customerId, ps, pe, quarter, user, allowOverlap) {
  if (!isIso_(ps) || !isIso_(pe)) fail_('Enter the billing period dates.');
  if (pe < ps) fail_('The billing period ends before it starts.');
  const cust = Db.must('Customers', customerId);
  if (quarter) {
    const existing = Db.where('Invoices', i => i.customer_id === customerId && i.quarter === quarter && i.status !== 'void')[0];
    if (existing) fail_('An invoice for ' + quarter + ' already exists (' + (existing.number || 'draft #' + existing.id) + ').');
  }
  const overlaps = overlapping_(customerId, ps, pe);
  if (overlaps.length && !allowOverlap) {
    fail_('This period overlaps an existing invoice: ' + overlaps.map(o => (o.number || 'draft #' + o.id) + ' (' + fmtPeriod_(o.period_start, o.period_end) + ')').join(', ') + '.');
  }
  const built = buildChargeLines_(customerId, ps, pe);
  if (!built.lines.length) fail_('No billable kits for ' + cust.billing_name + ' in this period.' + (built.warnings.length ? ' ' + built.warnings.join(' ') : ''));
  const inv = Db.insert('Invoices', {
    number: '', customer_id: customerId, kind: 'invoice', period_start: ps, period_end: pe, quarter: quarter || '',
    status: 'draft', invoice_date: '', due_date: '', total_c: 0, notes: '', pdf_file_id: '', replaces_invoice_id: null,
    created_by: user, created_at: now_(),
  });
  writeLines_(inv.id, built.lines);
  recalcTotal_(inv.id);
  audit_(user, 'invoice', inv.id, 'draft_created', fmtPeriod_(ps, pe) + (overlaps.length ? ' (overlap confirmed)' : ''));
  return { id: inv.id, warnings: built.warnings };
}

function generateQuarter_(quarter, user) {
  const qb = quarterBounds_(quarter);
  const created = [], skipped = [];
  eligibleCustomers_(qb[0], qb[1]).forEach(c => {
    try {
      const r = createDraft_(c.id, qb[0], qb[1], quarter, user, false);
      created.push({ customer: c.billing_name, id: r.id, warnings: r.warnings });
    } catch (e) {
      if (!e.userError) throw e;
      skipped.push({ customer: c.billing_name, reason: e.message });
    }
  });
  return { quarter, created, skipped };
}

function requireDraft_(invId) {
  const inv = Db.must('Invoices', invId);
  if (inv.status !== 'draft') fail_('Issued invoices can’t be edited. Use a credit adjustment, or void and reissue.');
  return inv;
}

function recalcDraft_(invId, user) {
  const inv = requireDraft_(invId);
  const built = buildChargeLines_(inv.customer_id, inv.period_start, inv.period_end);
  Db.where('InvoiceLines', l => l.invoice_id === inv.id && l.line_type === 'charge').map(l => l.id).forEach(id => Db.remove('InvoiceLines', id));
  writeLines_(inv.id, built.lines);
  recalcTotal_(inv.id);
  audit_(user, 'invoice', inv.id, 'charges_recalculated', '');
  return built.warnings;
}

function saveDraft_(invId, dueDate, notes, user) {
  requireDraft_(invId);
  if (dueDate && !isIso_(dueDate)) fail_('Enter a valid due date.');
  Db.update('Invoices', invId, { due_date: dueDate || '', notes: clean_(notes) });
  audit_(user, 'invoice', invId, 'draft_edited', 'due ' + (dueDate || 'default'));
}

function reviewLine_(invId, lineId, amountC, reason, user) {
  requireDraft_(invId);
  const l = Db.must('InvoiceLines', lineId);
  if (l.invoice_id !== Number(invId)) fail_('That line belongs to another invoice.');
  if (amountC === null) fail_('Enter an amount.');
  if (amountC !== l.amount_c && !clean_(reason)) fail_('Give a reason when you change a part-month amount.');
  Db.update('InvoiceLines', lineId, { amount_c: amountC, reviewed: true, reason: clean_(reason) || l.reason });
  recalcTotal_(Number(invId));
  audit_(user, 'invoice', invId, 'part_month_reviewed', l.description + ': ' + money_(l.amount_c) + ' → ' + money_(amountC) + ' ' + clean_(reason));
}

function addAdjustment_(invId, description, amountC, reason, user) {
  requireDraft_(invId);
  if (!clean_(reason)) fail_('Give a reason for the adjustment.');
  if (!amountC) fail_('Enter a non-zero amount.');
  const maxSort = Db.where('InvoiceLines', l => l.invoice_id === Number(invId)).reduce((m, l) => Math.max(m, l.sort || 0), 0);
  writeLines_(Number(invId), [{ line_type: 'adjustment', description: clean_(description) || 'Adjustment', amount_c: amountC,
                                reason: clean_(reason), reviewed: true }], maxSort + 1);
  recalcTotal_(Number(invId));
  audit_(user, 'invoice', invId, 'adjustment_added', money_(amountC) + ' – ' + reason);
}

function removeAdjustment_(invId, lineId, user) {
  requireDraft_(invId);
  const l = Db.must('InvoiceLines', lineId);
  if (l.invoice_id !== Number(invId) || l.line_type !== 'adjustment') fail_('Only adjustments can be removed.');
  Db.remove('InvoiceLines', lineId);
  recalcTotal_(Number(invId));
  audit_(user, 'invoice', invId, 'adjustment_removed', l.description + ' ' + money_(l.amount_c));
}

function deleteDraft_(invId, user) {
  const inv = requireDraft_(invId);
  Db.where('InvoiceLines', l => l.invoice_id === inv.id).map(l => l.id).forEach(id => Db.remove('InvoiceLines', id));
  Db.remove('Invoices', inv.id);
  audit_(user, 'invoice', inv.id, 'draft_deleted', fmtPeriod_(inv.period_start, inv.period_end));
  return inv.customer_id;
}

// ================================================================= issue, void, credit

function issueInvoice_(invId, user) {
  const checks = issueChecks_(invId);
  if (checks.blocking.length) fail_(checks.blocking.join(' '));
  const inv = Db.must('Invoices', invId);
  const s = settings_();
  const day = today_();
  const year = day.slice(0, 4);
  let number;
  do {
    number = (s.invoice_prefix || 'MTC') + '-' + year + '-' + String(nextSeq_('invoice_' + year)).padStart(4, '0');
  } while (Db.where('Invoices', i => i.number === number).length);
  const due = inv.due_date || addDays_(day, Number(s.default_due_days) || 30);
  Db.update('Invoices', inv.id, { number, status: 'issued', invoice_date: day, due_date: due, issued_by: user, issued_at: now_() });
  const fileId = writeInvoicePdf_(inv.id);
  Db.update('Invoices', inv.id, { pdf_file_id: fileId });
  audit_(user, 'invoice', inv.id, 'issued', number);
  return number;
}

function voidInvoice_(invId, reason, reissue, user) {
  const inv = Db.must('Invoices', invId);
  if (inv.status === 'void') fail_('This invoice is already void.');
  if (!clean_(reason)) fail_('Give a reason for voiding.');
  if (inv.status === 'draft') fail_('Drafts can be edited or deleted; there’s nothing to void.');
  if (Db.where('Credits', c => c.invoice_id === inv.id).length) fail_('This invoice has credit adjustments, so it can’t be voided. Add a further credit instead.');
  let returned = 0;
  Db.where('Allocations', a => a.invoice_id === inv.id && a.status === 'active').forEach(a => {
    Db.update('Allocations', a.id, { status: 'reversed', reversed_by: user, reversed_at: now_(), reverse_reason: 'Invoice voided: ' + reason });
    audit_(user, 'payment', a.payment_id, 'allocation_reversed', money_(a.amount_c) + ' returned to credit (invoice ' + inv.number + ' voided)');
    returned += a.amount_c;
  });
  Db.update('Invoices', inv.id, { status: 'void', voided_by: user, voided_at: now_(), void_reason: clean_(reason) });
  audit_(user, 'invoice', inv.id, 'voided', reason);
  let newId = null;
  if (reissue && inv.kind === 'invoice') {
    const copy = Db.insert('Invoices', {
      number: '', customer_id: inv.customer_id, kind: 'invoice', period_start: inv.period_start, period_end: inv.period_end,
      quarter: inv.quarter, status: 'draft', invoice_date: '', due_date: '', total_c: 0, notes: inv.notes, pdf_file_id: '',
      replaces_invoice_id: inv.id, created_by: user, created_at: now_(),
    });
    writeLines_(copy.id, Db.where('InvoiceLines', l => l.invoice_id === inv.id).sort((a, b) => a.sort - b.sort));
    recalcTotal_(copy.id);
    audit_(user, 'invoice', copy.id, 'draft_created', 'Replacement for ' + inv.number);
    newId = copy.id;
  }
  return { newId, returned };
}

function addCredit_(invId, amountC, reason, user) {
  const inv = getInvoice_(invId);
  if (inv.status !== 'issued') fail_('Credit adjustments apply to issued invoices only.');
  if (!clean_(reason)) fail_('Give a reason for the credit.');
  if (!amountC || amountC <= 0) fail_('Enter a credit amount above zero.');
  if (amountC > inv.balance_c) fail_('The credit can’t be more than the outstanding balance (' + money_(inv.balance_c) + ').');
  const number = (settings_().invoice_prefix || 'MTC') + '-CR-' + String(nextSeq_('credit')).padStart(4, '0');
  Db.insert('Credits', { number, customer_id: inv.customer_id, invoice_id: inv.id, credit_date: today_(), amount_c: amountC,
                         reason: clean_(reason), created_by: user, created_at: now_() });
  audit_(user, 'invoice', inv.id, 'credit_added', number + ' ' + money_(amountC) + ' – ' + reason);
  return number;
}

function setOpening_(customerId, amountC, asOf, user) {
  if (!isIso_(asOf)) fail_('Enter the date of the opening balance.');
  const cust = Db.must('Customers', customerId);
  const existing = Db.where('Invoices', i => i.customer_id === cust.id && i.kind === 'opening' && i.status !== 'void')[0];
  if (existing) {
    const v = getInvoice_(existing.id);
    if (v.paid_c || v.credited_c) fail_('Payments are applied to the opening balance. Unapply them first to change it.');
    if (!amountC) {
      Db.update('Invoices', existing.id, { status: 'void', voided_by: user, voided_at: now_(), void_reason: 'Opening balance cleared' });
    } else {
      Db.update('Invoices', existing.id, { total_c: amountC, invoice_date: asOf, due_date: asOf, period_start: asOf, period_end: asOf });
    }
  } else if (amountC) {
    Db.insert('Invoices', {
      number: 'OPENING-' + cust.code, customer_id: cust.id, kind: 'opening', period_start: asOf, period_end: asOf, quarter: '',
      status: 'issued', invoice_date: asOf, due_date: asOf, total_c: amountC, notes: 'Opening balance', pdf_file_id: '',
      replaces_invoice_id: null, created_by: user, created_at: now_(), issued_by: user, issued_at: now_(),
    });
  }
  audit_(user, 'customer', cust.id, 'opening_balance_set', money_(amountC || 0));
}

// ================================================================= statement

function statement_(customerId, start, end) {
  const entries = [];
  Db.where('Invoices', i => i.customer_id === customerId && i.status === 'issued').forEach(i => entries.push({
    date: i.invoice_date, order: 0, kind: 'invoice', invoice_id: i.id, debit: i.total_c, credit: 0,
    label: i.kind === 'opening' ? 'Opening balance' : 'Invoice ' + i.number + ' – ' + fmtPeriod_(i.period_start, i.period_end),
  }));
  const numbers = {};
  Db.all('Invoices').forEach(i => { numbers[i.id] = i.number; });
  Db.where('Credits', c => c.customer_id === customerId).forEach(c => entries.push({
    date: c.credit_date, order: 1, kind: 'credit', invoice_id: c.invoice_id, debit: 0, credit: c.amount_c,
    label: 'Credit ' + c.number + ' on ' + numbers[c.invoice_id] + ' – ' + c.reason,
  }));
  Db.where('Payments', p => p.customer_id === customerId && p.status === 'active').forEach(p => entries.push({
    date: p.received_date, order: 2, kind: 'payment', payment_id: p.id, debit: 0, credit: p.amount_c,
    label: 'Payment – ' + (METHODS[p.method] || p.method) + (p.reference ? ' ref ' + p.reference : ''),
  }));
  entries.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.order - b.order));
  let balance = 0, brought = 0;
  const out = [];
  entries.forEach(e => {
    if (start && e.date < start) { brought += e.debit - e.credit; balance += e.debit - e.credit; return; }
    if (end && e.date > end) return;
    balance += e.debit - e.credit;
    e.balance = balance;
    out.push(e);
  });
  return { entries: out, brought_forward: brought, closing: balance };
}
