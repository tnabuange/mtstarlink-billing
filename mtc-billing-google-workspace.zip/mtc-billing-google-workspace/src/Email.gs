/** Invoice emails, manual reminders and automatic reminders (sent with Gmail from the deploying account). */

function parseOffsets_(text) {
  const out = [];
  String(text || '').split(',').forEach(p => {
    p = p.trim();
    if (!p) return;
    if (!/^[+-]?\d+$/.test(p)) fail_('Reminder timing must be whole numbers of days, e.g. -7, 7, 14.');
    out.push(Number(p));
  });
  return Array.from(new Set(out)).sort((a, b) => a - b);
}
function stageKey_(off) { return 'due' + (off >= 0 ? '+' : '') + off; }
function stageLabel_(stage) {
  if (stage === 'manual') return 'Manual';
  const n = Number(stage.slice(3));
  return n < 0 ? -n + ' days before due' : n === 0 ? 'On due date' : n + ' days after due';
}

function senderEmail_() {
  try { return Session.getEffectiveUser().getEmail(); } catch (e) { return ''; }
}

function senderProblems_(s) {
  const out = [];
  if (!s.sender_name) out.push('Add a sender name in Settings.');
  return out;
}

function compose_(inv, cust, s, kind) {
  const officer = cust.officer_name || 'Sir/Madam';
  const period = fmtPeriod_(inv.period_start, inv.period_end);
  const bal = money_(inv.balance_c), due = fmtDate_(inv.due_date);
  const sign = 'Thank you,\n' + s.sender_name + '\n' + s.company_name;
  if (kind === 'invoice') {
    return {
      subject: 'Invoice ' + inv.number + ' – Starlink services for ' + cust.billing_name + ' (' + period + ')',
      body: 'Dear ' + officer + ',\n\nPlease find attached ' + s.company_name + ' invoice ' + inv.number +
        ' for Starlink services provided to ' + cust.billing_name + ' during ' + period + '. The amount outstanding is ' + bal +
        ', due on ' + due + '.\n\nPlease use ' + inv.number + ' as the payment reference. If you have any questions, just reply to this email.\n\n' + sign,
    };
  }
  if (inv.due_date < today_()) {
    return {
      subject: 'Overdue: invoice ' + inv.number + ' – ' + bal + ' outstanding',
      body: 'Dear ' + officer + ',\nI’m following up on ' + s.company_name + ' invoice ' + inv.number + ' for Starlink services provided to ' +
        cust.billing_name + ' during ' + period + '. The outstanding balance is ' + bal + ', and the invoice was due on ' + due +
        '. I’ve attached a copy for your reference.\n\nCould you please let me know when payment is expected? If payment has already been made, ' +
        'please send the transaction reference so I can update our records.\n\n' + sign,
    };
  }
  return {
    subject: 'Reminder: invoice ' + inv.number + ' due ' + due + ' – ' + bal + ' outstanding',
    body: 'Dear ' + officer + ',\nThis is a friendly reminder that ' + s.company_name + ' invoice ' + inv.number + ' for Starlink services provided to ' +
      cust.billing_name + ' during ' + period + ' is due on ' + due + '. The outstanding balance is ' + bal +
      '. I’ve attached a copy for your reference.\n\nIf payment has already been made, please send the transaction reference so I can update our records.\n\n' + sign,
  };
}

function buildEmail_(invId, kind) {
  const inv = getInvoice_(invId);
  const cust = Db.must('Customers', inv.customer_id);
  const s = settings_();
  const msg = compose_(inv, cust, s, kind);
  const to = splitAddrs_(cust.officer_email);
  const lower = to.map(a => a.toLowerCase());
  const cc = splitAddrs_(cust.cc_email).filter(a => lower.indexOf(a.toLowerCase()) < 0);
  return { inv, cust, settings: s, to, cc, subject: msg.subject, body: msg.body, balance_c: inv.balance_c,
           pdf_name: inv.number + '.pdf', from: senderEmail_() };
}

function emailBlockers_(m, kind) {
  const out = [];
  if (m.inv.kind !== 'invoice') out.push('Opening balances have no invoice PDF to send.');
  if (m.inv.status !== 'issued') out.push(m.inv.status === 'draft' ? 'Only issued invoices can be emailed.' : 'This invoice is void.');
  customerMissingForEmail_(m.cust).forEach(x => out.push('The account is missing the ' + x + '.'));
  m.to.concat(m.cc).forEach(a => { if (!EMAIL_RE.test(a)) out.push('"' + a + '" doesn’t look like an email address.'); });
  if (kind === 'reminder' && m.inv.balance_c <= 0) out.push('Nothing is outstanding on this invoice.');
  if (m.inv.kind === 'invoice' && m.inv.status === 'issued' && !m.inv.pdf_file_id) out.push('The invoice PDF is missing.');
  return out.concat(senderProblems_(m.settings));
}

function logEmail_(m, kind, stage, trigger, user, status) {
  return Db.insert('EmailLog', {
    invoice_id: m.inv.id, customer_id: m.cust.id, kind, stage, trigger, to: m.to.join(', '), cc: m.cc.join(', '),
    subject: m.subject, balance_c: m.balance_c, status, response: '', error: '', sent_by: user, created_at: now_(), sent_at: '',
  });
}

/** Re-reads the balance immediately before sending. Returns {ok, message}. */
function sendInvoiceEmail_(invId, kind, user, trigger, stage, expectedBalance) {
  trigger = trigger || 'manual';
  stage = stage || 'manual';
  Db.reset();
  let m = buildEmail_(invId, kind);
  const problems = emailBlockers_(m, kind);
  if (expectedBalance !== undefined && expectedBalance !== null && Number(expectedBalance) !== m.balance_c) {
    problems.push('The balance changed to ' + money_(m.balance_c) + ' since you opened the preview. Check the preview again.');
  }
  if (problems.length) return { ok: false, message: problems.join(' ') };

  if (trigger === 'auto' && Db.where('EmailLog', l => l.invoice_id === m.inv.id && l.stage === stage && l.trigger === 'auto' &&
      ['pending', 'sent', 'skipped'].indexOf(l.status) >= 0).length) {
    return { ok: false, message: 'This automatic reminder was already sent.' };
  }
  const log = logEmail_(m, kind, stage, trigger, user, 'pending');

  // Final check against fresh data right before handing the message to Gmail.
  Db.reset();
  const fresh = getInvoice_(invId);
  if (fresh.status !== 'issued' || (kind === 'reminder' && fresh.balance_c <= 0)) {
    Db.update('EmailLog', log.id, { status: 'skipped', error: 'Invoice paid or voided just before sending' });
    return { ok: false, message: 'Not sent: the invoice was paid or voided just before sending.' };
  }
  if (fresh.balance_c !== m.balance_c) m = buildEmail_(invId, kind);

  try {
    const opts = { to: m.to.join(','), subject: m.subject, body: m.body, name: m.settings.sender_name,
                   attachments: [invoicePdfBlob_(m.inv)] };
    if (m.cc.length) opts.cc = m.cc.join(',');
    if (m.settings.reply_to) opts.replyTo = m.settings.reply_to;
    MailApp.sendEmail(opts);
  } catch (e) {
    Db.update('EmailLog', log.id, { status: 'failed', error: String(e.message || e), sent_at: now_() });
    audit_(user, 'invoice', m.inv.id, kind + '_email_failed', String(e.message || e));
    return { ok: false, message: 'Email failed: ' + (e.message || e) };
  }
  Db.update('EmailLog', log.id, { status: 'sent', response: 'Accepted by Gmail for delivery', sent_at: now_(), balance_c: m.balance_c });
  audit_(user, 'invoice', m.inv.id, kind + '_emailed', 'to ' + m.to.join(', ') + (m.cc.length ? ' cc ' + m.cc.join(', ') : ''));
  return { ok: true, message: 'Sent to ' + m.to.concat(m.cc).join(', ') + '.' };
}

function dueStage_(inv, offsets, today) {
  const applicable = offsets.filter(off => today >= addDays_(inv.due_date, off) && !(off < 0 && today >= inv.due_date));
  return applicable.length ? stageKey_(Math.max.apply(null, applicable)) : null;
}

/** Sends whatever automatic reminders are due. Safe to run any number of times. */
function runAutoReminders_(user, force) {
  const s = settings_();
  const out = { sent: [], skipped: [], failed: [], disabled: false };
  if (!/^(yes|true|1)$/i.test(s.reminders_enabled) && !force) { out.disabled = true; return out; }
  const sp = senderProblems_(s);
  if (sp.length) { out.failed.push(['—', sp.join(' ')]); return out; }
  const offsets = parseOffsets_(s.reminder_offsets);
  const t = today_();
  listInvoices_({ state: 'outstanding' }).forEach(inv => {
    if (inv.kind !== 'invoice' || !isIso_(inv.due_date)) return;
    const stage = dueStage_(inv, offsets, t);
    if (!stage) return;
    if (Db.where('EmailLog', l => l.invoice_id === inv.id && l.stage === stage && l.trigger === 'auto' &&
        ['pending', 'sent', 'skipped'].indexOf(l.status) >= 0).length) return;
    if (inv.reminders_paused) { out.skipped.push([inv.number, 'Reminders paused for this account']); return; }
    if (!inv.officer_email) { out.skipped.push([inv.number, 'No billing email']); return; }
    const r = sendInvoiceEmail_(inv.id, 'reminder', user, 'auto', stage);
    (r.ok ? out.sent : out.failed).push([inv.number, stageLabel_(stage) + ': ' + r.message]);
  });
  return out;
}

function nextAutoStage_(inv, s) {
  if (!/^(yes|true|1)$/i.test(s.reminders_enabled) || ['unpaid', 'partial'].indexOf(inv.state) < 0 || inv.kind !== 'invoice') return null;
  const done = new Set(Db.where('EmailLog', l => l.invoice_id === inv.id && l.trigger === 'auto' &&
    ['pending', 'sent', 'skipped'].indexOf(l.status) >= 0).map(l => l.stage));
  const t = today_();
  let offsets;
  try { offsets = parseOffsets_(s.reminder_offsets); } catch (e) { return null; }
  for (const off of offsets) {
    const when = addDays_(inv.due_date, off);
    if (done.has(stageKey_(off)) || when < t) continue;
    return { date: when, label: stageLabel_(stageKey_(off)) };
  }
  return null;
}

// ------------------------------------------------------------------ hourly trigger

/** Entry point for the hourly time-driven trigger. */
function reminderTrigger() {
  withLock_(() => {
    runAutoReminders_('auto-reminder');
    refreshReport_();
  });
}

function setReminderTrigger_(enabled) {
  ScriptApp.getProjectTriggers().filter(t => t.getHandlerFunction() === 'reminderTrigger').forEach(t => ScriptApp.deleteTrigger(t));
  if (enabled) ScriptApp.newTrigger('reminderTrigger').timeBased().everyHours(1).create();
}

function reminderTriggerInstalled_() {
  return ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === 'reminderTrigger');
}
