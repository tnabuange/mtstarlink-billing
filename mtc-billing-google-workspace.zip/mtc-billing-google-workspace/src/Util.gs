/** Small helpers: errors, money (integer cents), dates (ISO text in Pacific/Tarawa). */

class UserError extends Error {
  constructor(message) { super(message); this.userError = true; }
}

function fail_(message) { throw new UserError(message); }

// ------------------------------------------------------------------ time

function today_() {
  if (typeof TEST_TODAY !== 'undefined' && TEST_TODAY) return TEST_TODAY;
  return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
}

function now_() {
  return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss');
}

function isIso_(s) {
  return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(Date.parse(s + 'T00:00:00Z'));
}

function utc_(iso) { return new Date(iso + 'T00:00:00Z'); }
function iso_(dt) { return dt.toISOString().slice(0, 10); }
function addDays_(iso, n) { const d = utc_(iso); d.setUTCDate(d.getUTCDate() + n); return iso_(d); }
function daysBetween_(a, b) { return Math.round((utc_(b) - utc_(a)) / 86400000); }
function daysInMonth_(iso) { const d = utc_(iso); return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate(); }
function monthFirst_(iso) { return iso.slice(0, 8) + '01'; }
function monthLast_(iso) { return iso.slice(0, 8) + String(daysInMonth_(iso)).padStart(2, '0'); }
function minIso_(a, b) { return a < b ? a : b; }
function maxIso_(a, b) { return a > b ? a : b; }

function quarterKey_(year, q) { return year + '-Q' + q; }
function quarterOf_(iso) { return quarterKey_(Number(iso.slice(0, 4)), Math.floor((Number(iso.slice(5, 7)) - 1) / 3) + 1); }
function quarterBounds_(key) {
  const m = /^(\d{4})-Q([1-4])$/.exec(key || '');
  if (!m) fail_('Choose a quarter.');
  const y = Number(m[1]), q = Number(m[2]);
  const start = y + '-' + String(3 * (q - 1) + 1).padStart(2, '0') + '-01';
  const end = monthLast_(y + '-' + String(3 * q).padStart(2, '0') + '-01');
  return [start, end];
}
function recentQuarters_(back, forward) {
  const cur = quarterOf_(today_());
  const y = Number(cur.slice(0, 4)), q = Number(cur.slice(-1));
  const out = [];
  for (let off = forward; off >= -back; off--) {
    const idx = y * 4 + (q - 1) + off;
    out.push(quarterKey_(Math.floor(idx / 4), (idx % 4) + 1));
  }
  return out;
}

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function fmtDate_(iso) {
  if (!isIso_(iso)) return iso || '';
  return iso.slice(8, 10) + ' ' + MONTHS[Number(iso.slice(5, 7)) - 1] + ' ' + iso.slice(0, 4);
}
function fmtPeriod_(a, b) {
  if (!isIso_(a) || !isIso_(b)) return '';
  const da = Number(a.slice(8, 10)), db = Number(b.slice(8, 10));
  const ma = MONTHS[Number(a.slice(5, 7)) - 1], mb = MONTHS[Number(b.slice(5, 7)) - 1];
  if (a.slice(0, 4) === b.slice(0, 4)) {
    if (a.slice(0, 7) === b.slice(0, 7)) return da + '–' + db + ' ' + mb + ' ' + b.slice(0, 4);
    return da + ' ' + ma + ' – ' + db + ' ' + mb + ' ' + b.slice(0, 4);
  }
  return fmtDate_(a) + ' – ' + fmtDate_(b);
}

// ------------------------------------------------------------------ money (cents)

/** '1,234.5' → 123450, '' → null. Exact decimal parsing, no floating point drift. */
function toCents_(v) {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return Math.round(v * 100);
  let s = String(v).replace(/AUD|\$|,|\s/gi, '');
  if (s === '') return null;
  if (!/^-?\d*(\.\d*)?$/.test(s) || s === '-' || s === '.') fail_("'" + v + "' is not a valid amount.");
  const neg = s[0] === '-';
  if (neg) s = s.slice(1);
  const parts = s.split('.');
  const frac = ((parts[1] || '') + '000');
  let c = Number(parts[0] || '0') * 100 + Number(frac.slice(0, 2));
  if (Number(frac[2]) >= 5) c += 1;
  return neg ? -c : c;
}

function money_(c) {
  if (c === null || c === undefined) return '—';
  const neg = c < 0; c = Math.abs(Math.round(c));
  const s = Math.floor(c / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + '.' + String(c % 100).padStart(2, '0');
  return (neg ? '-' : '') + 'AUD ' + s;
}

function plainMoney_(c) {
  if (c === null || c === undefined) return '';
  return (c < 0 ? '-' : '') + Math.floor(Math.abs(c) / 100) + '.' + String(Math.abs(c) % 100).padStart(2, '0');
}

function sum_(arr, fn) { return arr.reduce((t, x) => t + (fn ? fn(x) : x), 0); }

// ------------------------------------------------------------------ text

const EMAIL_RE = /^[^@\s,;]+@[^@\s,;]+\.[^@\s,;]+$/;
function splitAddrs_(v) { return String(v || '').split(/[,;\s]+/).map(s => s.trim()).filter(Boolean); }
function clean_(v) { return v === null || v === undefined ? '' : String(v).trim(); }
function htmlEsc_(s) {
  return String(s === null || s === undefined ? '' : s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
}
