/** First-time setup, the sheet menu, and the read-only "Invoice balances" report tab. */

function onOpen() {
  SpreadsheetApp.getUi().createMenu('MTC Billing')
    .addItem('Open the billing app', 'showAppLink')
    .addItem('Refresh the Invoice balances tab', 'refreshReportMenu')
    .addItem('Run automatic reminders now', 'reminderTrigger')
    .addItem('Back up now (copy of this spreadsheet)', 'backupNow')
    .addSeparator()
    .addItem('First-time setup (safe to rerun)', 'setup')
    .addToUi();
}

/**
 * Creates the tabs and headers, sets the time zone, adds the 13 starter accounts (only if Customers is empty),
 * creates the private Drive folders and adds you to the Staff tab. Safe to run again.
 */
function setup() {
  const ss = SpreadsheetApp.getActive();
  ss.setSpreadsheetTimeZone(TZ);
  Object.keys(SCHEMA).forEach(name => {
    let sh = ss.getSheetByName(name);
    if (!sh) sh = ss.insertSheet(name);
    const cols = SCHEMA[name];
    const head = sh.getLastRow() ? sh.getRange(1, 1, 1, Math.max(sh.getLastColumn(), 1)).getValues()[0].map(String) : [];
    if (!head.filter(Boolean).length) {
      sh.getRange(1, 1, 1, cols.length).setValues([cols]);
    } else {
      // Add any columns introduced by an update, at the end, without moving existing data.
      const missing = cols.filter(c => head.indexOf(c) < 0);
      if (missing.length) sh.getRange(1, head.length + 1, 1, missing.length).setValues([missing]);
    }
    sh.setFrozenRows(1);
    sh.getRange(1, 1, 1, sh.getLastColumn()).setFontWeight('bold').setBackground('#e3f1f2');
    cols.forEach((c, i) => {
      if (/_aud$/.test(c)) sh.getRange(2, i + 1, sh.getMaxRows() - 1, 1).setNumberFormat('#,##0.00');
    });
  });

  const settings = ss.getSheetByName('Settings');
  const have = settings.getDataRange().getValues().slice(1).map(r => String(r[0]));
  SETTINGS_DEFAULTS.forEach(s => { if (have.indexOf(s[0]) < 0) settings.appendRow([s[0], textCell_(s[1]), s[2]]); });

  Db.reset();
  if (!Db.all('Customers').length) {
    STARTER_ACCOUNTS.forEach(a => Db.insert('Customers', {
      code: a[0], billing_name: a[1], school_division: '', location: a[2] || '', officer_name: '', officer_email: '',
      cc_email: '', notes: a[3] || '', reminders_paused: false, active: true, created_at: now_(), updated_at: now_(),
    }));
  }

  const me = (Session.getEffectiveUser().getEmail() || '').toLowerCase();
  const staff = ss.getSheetByName('Staff');
  if (me && !staff.getDataRange().getValues().slice(1).some(r => String(r[0]).toLowerCase() === me)) staff.appendRow([me, 'Owner', 'yes']);

  // Tabs the app manages: editing them by hand skips the checks and the audit trail, so Sheets warns first.
  const ownerOnly = ['Invoices', 'InvoiceLines', 'Payments', 'Allocations', 'Credits', 'EmailLog', 'Audit'];
  ownerOnly.forEach(n => {
    const sh = ss.getSheetByName(n);
    if (!sh.getProtections(SpreadsheetApp.ProtectionType.SHEET).length) {
      sh.protect().setDescription('Managed by the MTC Billing app – change these records in the app').setWarningOnly(true);
    }
  });

  invoiceFolder_();
  evidenceFolder_();
  if (!ScriptApp.getProjectTriggers().some(t => t.getHandlerFunction() === 'weeklyBackup')) {
    ScriptApp.newTrigger('weeklyBackup').timeBased().everyWeeks(1).create();
  }
  refreshReport_();
  ['Sheet1', 'Sheet 1'].forEach(n => { const s1 = ss.getSheetByName(n); if (s1 && ss.getSheets().length > 1 && s1.getLastRow() === 0) ss.deleteSheet(s1); });
  try {
    SpreadsheetApp.getUi().alert('MTC Billing is set up. Next: Deploy → New deployment → Web app (see the README).');
  } catch (e) { /* run from the editor: no UI */ }
}

/** Rewrites the "Invoice balances" tab from the raw data (one row per invoice, with paid, credited and balance). */
function refreshReport_() {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(REPORT_SHEET);
  if (!sh) { sh = ss.insertSheet(REPORT_SHEET); sh.setFrozenRows(1); }
  const rows = invoiceReportRows_(listInvoices_({}).filter(r => r.status !== 'draft'))
    .map(r => r.slice(0, 11).concat(r.slice(11).map(Number)));
  sh.clearContents();
  sh.getRange(1, 1, 1, REPORT_HEADERS.length).setValues([REPORT_HEADERS]).setFontWeight('bold').setBackground('#e3f1f2');
  if (rows.length) {
    sh.getRange(2, 1, rows.length, REPORT_HEADERS.length).setValues(rows.map(r => r.map((v, i) => (i < 11 ? textCell_(String(v)) : v))));
    sh.getRange(2, 12, rows.length, 4).setNumberFormat('#,##0.00');
  }
  sh.getRange(rows.length + 3, 1).setValue('Updated ' + now_() + ' (Pacific/Tarawa). Rebuilt automatically – edits here are overwritten.');
}

/** Saves a full copy of the spreadsheet (all tabs) in the "MTC Billing – Backups" Drive folder. */
function backupNow() {
  const ss = SpreadsheetApp.getActive();
  const name = 'MTC Billing backup ' + now_().replace(/:/g, '.');
  const copy = DriveApp.getFileById(ss.getId()).makeCopy(name, folder_('backup_folder_id', 'MTC Billing – Backups'));
  try { SpreadsheetApp.getUi().alert('Backup saved to Drive: ' + name); } catch (e) { /* trigger: no UI */ }
  return copy.getId();
}

/** Weekly trigger: one backup copy, keeping the latest 12 (about three months). */
function weeklyBackup() {
  backupNow();
  const files = [];
  const it = folder_('backup_folder_id', 'MTC Billing – Backups').getFiles();
  while (it.hasNext()) files.push(it.next());
  files.sort((a, b) => b.getDateCreated() - a.getDateCreated()).slice(12).forEach(f => f.setTrashed(true));
}

function refreshReportMenu() {
  withLock_(() => refreshReport_());
}

function showAppLink() {
  let url = '';
  try { url = ScriptApp.getService().getUrl(); } catch (e) { url = ''; }
  const html = url
    ? '<p style="font-family:sans-serif">Open the billing app:<br><a href="' + url + '" target="_blank">' + url + '</a></p>'
    : '<p style="font-family:sans-serif">The web app isn’t deployed yet. In the Apps Script editor choose Deploy → New deployment → Web app.</p>';
  SpreadsheetApp.getUi().showModalDialog(HtmlService.createHtmlOutput(html).setWidth(420).setHeight(140), 'MTC Billing');
}
