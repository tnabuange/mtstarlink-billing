/**
 * MT Creatives Trading – Starlink Billing & Payments (Google Workspace edition)
 *
 * The Google Sheet is the database: one tab per table, one row per record, headers in row 1.
 * Columns ending in _aud are AUD amounts (numbers). Dates are text yyyy-mm-dd in Pacific/Tarawa.
 */
const TZ = 'Pacific/Tarawa';

const SCHEMA = {
  Customers: ['id', 'code', 'billing_name', 'school_division', 'location', 'officer_name', 'officer_email', 'cc_email',
              'notes', 'reminders_paused', 'active', 'created_at', 'updated_at'],
  Kits: ['id', 'customer_id', 'kit_ref', 'service_location', 'plan', 'billing_start', 'billing_end', 'status', 'notes', 'created_at'],
  Rates: ['id', 'kit_id', 'effective_from', 'monthly_aud', 'note', 'created_by', 'created_at'],
  Invoices: ['id', 'number', 'customer_id', 'kind', 'period_start', 'period_end', 'quarter', 'status', 'invoice_date', 'due_date',
             'total_aud', 'notes', 'pdf_file_id', 'replaces_invoice_id', 'created_by', 'created_at', 'issued_by', 'issued_at',
             'voided_by', 'voided_at', 'void_reason'],
  InvoiceLines: ['id', 'invoice_id', 'kit_id', 'line_type', 'description', 'period_start', 'period_end', 'rate_aud', 'months',
                 'amount_aud', 'is_partial', 'reviewed', 'reason', 'sort'],
  Payments: ['id', 'customer_id', 'received_date', 'amount_aud', 'payer', 'reference', 'method', 'notes', 'proof_file_id',
             'proof_name', 'status', 'created_by', 'created_at', 'reversed_by', 'reversed_at', 'reverse_reason'],
  Allocations: ['id', 'payment_id', 'invoice_id', 'amount_aud', 'status', 'created_by', 'created_at', 'reversed_by', 'reversed_at',
                'reverse_reason'],
  Credits: ['id', 'number', 'customer_id', 'invoice_id', 'credit_date', 'amount_aud', 'reason', 'created_by', 'created_at'],
  EmailLog: ['id', 'invoice_id', 'customer_id', 'kind', 'stage', 'trigger', 'to', 'cc', 'subject', 'balance_aud', 'status',
             'response', 'error', 'sent_by', 'created_at', 'sent_at'],
  Audit: ['at', 'user', 'entity', 'entity_id', 'action', 'detail'],
  Settings: ['key', 'value', 'about'],
  Staff: ['email', 'name', 'active'],
};

// Read-only summary tab, rebuilt after every change. Handy for filters, pivots and charts.
const REPORT_SHEET = 'Invoice balances';
const REPORT_HEADERS = ['Invoice', 'Account code', 'Customer', 'Type', 'Period start', 'Period end', 'Quarter', 'Invoice date',
                        'Due date', 'Status', 'Overdue', 'Total AUD', 'Paid AUD', 'Credited AUD', 'Balance AUD'];

const BOOL_COLS = ['reminders_paused', 'active', 'is_partial', 'reviewed'];
const DATE_COLS = ['billing_start', 'billing_end', 'effective_from', 'period_start', 'period_end', 'invoice_date', 'due_date',
                   'received_date', 'credit_date'];

const METHODS = { bank_transfer: 'Bank transfer', deposit: 'Bank deposit', cash: 'Cash', cheque: 'Cheque', other: 'Other' };
const KIT_STATUSES = ['active', 'suspended', 'ended'];
const PROOF_TYPES = { pdf: 'application/pdf', jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', heic: 'image/heic', webp: 'image/webp' };
const MAX_PROOF_BYTES = 10 * 1024 * 1024;

const STARTER_ACCOUNTS = [
  ['KNLA', 'KNLA', ''], ['CDRC', 'CDRC', ''], ['EAU', 'EAU', ''], ['KTC', 'KTC', ''],
  ['KGV-EBS', 'KGV & EBS', '', 'Combined billing account for KGV and EBS. To bill them separately, add a new account and move the relevant kits to it.'],
  ['TEABIKE', 'Teabike College', ''], ['LPSSS', 'LPSSS', ''],
  ['MARAKEI-JSS', 'Marakei JSS', 'Marakei'], ['TAMANA-JSS', 'Tamana JSS', 'Tamana'], ['NIKUNAU-JSS', 'Nikunau JSS', 'Nikunau'],
  ['ONOTOA-JSS', 'Onotoa JSS', 'Onotoa'], ['BANABA-JSS', 'Banaba JSS', 'Banaba'], ['BUTARITARI-JSS', 'Butaritari JSS', 'Butaritari'],
];

// [key, default, explanation shown in the Settings tab]
const SETTINGS_DEFAULTS = [
  ['company_name', 'MT Creatives Trading', 'Shown at the top of invoices'],
  ['company_address', '', ''],
  ['company_phone', '', ''],
  ['company_email', '', ''],
  ['company_reg', '', 'Business registration (optional)'],
  ['bank_account_name', '', ''],
  ['bank_name', '', ''],
  ['bank_branch', '', 'Branch or BSB'],
  ['bank_account_number', '', ''],
  ['bank_swift', '', 'Optional'],
  ['payment_instructions', '', 'Extra text printed under the bank details'],
  ['sender_name', '', 'Signs emails, e.g. your full name. Emails are sent from the Google account that deployed the app.'],
  ['reply_to', '', 'Optional reply-to address'],
  ['invoice_prefix', 'MTC', 'Invoice numbers look like MTC-2026-0001'],
  ['default_due_days', '30', 'Days after the invoice date, unless a draft has its own due date'],
  ['reminders_enabled', 'no', 'Turn on from the app’s Settings page so the hourly trigger is installed'],
  ['reminder_offsets', '-7, 7, 14', 'Days from the due date. Negative = before.'],
];
