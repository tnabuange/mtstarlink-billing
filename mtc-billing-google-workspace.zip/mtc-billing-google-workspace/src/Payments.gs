/** Payments, allocations to invoices, customer credit, corrections and reversals. */

function findDuplicates_(customerId, amountC, received, reference, excludeId) {
  const ref = clean_(reference).toLowerCase();
  const lo = addDays_(received, -3), hi = addDays_(received, 3);
  const names = {};
  Db.all('Customers').forEach(c => { names[c.id] = c.billing_name; });
  return Db.where('Payments', p => p.status === 'active' && p.id !== excludeId && (
    (ref && p.reference.toLowerCase() === ref) ||
    (p.customer_id === customerId && p.amount_c === amountC && p.received_date >= lo && p.received_date <= hi)))
    .map(p => ({ id: p.id, received_date: p.received_date, amount_c: p.amount_c, reference: p.reference, billing_name: names[p.customer_id] }));
}

function applyToInvoice_(paymentId, invoiceId, amountC, user) {
  const inv = getInvoice_(invoiceId);
  const pay = Db.must('Payments', paymentId);
  if (inv.customer_id !== pay.customer_id) fail_('Payments can only be applied to the same account’s invoices.');
  if (inv.status !== 'issued') fail_(inv.label + ' is not issued.');
  if (amountC > inv.balance_c) fail_(money_(amountC) + ' is more than the balance of ' + inv.label + ' (' + money_(inv.balance_c) + ').');
  if (amountC > paymentUnapplied_(paymentId)) fail_('There isn’t enough unapplied money on this payment.');
  Db.insert('Allocations', { payment_id: pay.id, invoice_id: inv.id, amount_c: amountC, status: 'active', created_by: user, created_at: now_() });
  audit_(user, 'payment', pay.id, 'applied', money_(amountC) + ' to ' + inv.label);
}

/** Checks every allocation before anything is written: a Sheet can't roll back a half-finished change. */
function validateAllocations_(customerId, allocs) {
  const seen = {};
  allocs.forEach(a => {
    const inv = getInvoice_(a[0]);
    if (inv.customer_id !== customerId) fail_('Payments can only be applied to the same account’s invoices.');
    if (inv.status !== 'issued') fail_(inv.label + ' is not issued.');
    seen[inv.id] = (seen[inv.id] || 0) + a[1];
    if (seen[inv.id] > inv.balance_c) fail_(money_(seen[inv.id]) + ' is more than the balance of ' + inv.label + ' (' + money_(inv.balance_c) + ').');
  });
}

function oldestFirst_(customerId, amountC) {
  const out = [];
  let remaining = amountC;
  listInvoices_({ customer_id: customerId, state: 'outstanding' })
    .sort((a, b) => (a.due_date < b.due_date ? -1 : a.due_date > b.due_date ? 1 : a.id - b.id))
    .forEach(inv => {
      if (remaining <= 0) return;
      const take = Math.min(remaining, inv.balance_c);
      out.push([inv.id, take]);
      remaining -= take;
    });
  return out;
}

/**
 * p: {customer_id, amount, received_date, payer, reference, method, notes, apply_mode, allocations:{invoiceId: amount},
 *     confirm_duplicate, proof:{name, mime, base64}}
 */
function recordPayment_(p, user) {
  const customerId = Number(p.customer_id);
  Db.must('Customers', customerId);
  const amountC = toCents_(p.amount);
  if (!amountC || amountC <= 0) fail_('Enter a payment amount above zero.');
  if (!isIso_(p.received_date)) fail_('Enter the date the payment was received.');
  if (p.received_date > today_()) fail_('The received date is in the future.');
  if (!METHODS[p.method]) fail_('Choose a payment method.');

  let proofExt = '', proofBytes = null;
  if (p.proof && p.proof.base64) {
    proofExt = String(p.proof.name || '').split('.').pop().toLowerCase();
    if (!PROOF_TYPES[proofExt]) fail_('Proof of payment must be a PDF or an image (JPG, PNG, HEIC, WEBP).');
    proofBytes = Utilities.base64Decode(p.proof.base64);
    if (proofBytes.length > MAX_PROOF_BYTES) fail_('The proof file is larger than 10 MB.');
  }

  if (!p.confirm_duplicate) {
    const dupes = findDuplicates_(customerId, amountC, p.received_date, p.reference);
    if (dupes.length) return { duplicates: dupes };
  }

  let allocs = [];
  if (p.apply_mode === 'oldest') allocs = oldestFirst_(customerId, amountC);
  else if (p.apply_mode === 'manual') {
    allocs = Object.keys(p.allocations || {}).map(k => [Number(k), toCents_(p.allocations[k]) || 0]).filter(a => a[1] > 0);
  }
  const applied = sum_(allocs, a => a[1]);
  if (applied > amountC) fail_('You applied ' + money_(applied) + ' but the payment is only ' + money_(amountC) + '.');
  validateAllocations_(customerId, allocs);

  let proofId = '', proofName = '';
  if (proofBytes) {
    const blob = Utilities.newBlob(proofBytes, PROOF_TYPES[proofExt], Utilities.getUuid() + '.' + proofExt);
    proofId = evidenceFolder_().createFile(blob).getId();
    proofName = String(p.proof.name).slice(0, 120);
  }

  const pay = Db.insert('Payments', {
    customer_id: customerId, received_date: p.received_date, amount_c: amountC, payer: clean_(p.payer),
    reference: clean_(p.reference), method: p.method, notes: clean_(p.notes), proof_file_id: proofId, proof_name: proofName,
    status: 'active', created_by: user, created_at: now_(),
  });
  audit_(user, 'payment', pay.id, 'recorded', money_(amountC) + ' ref ' + (pay.reference || '—'));
  allocs.forEach(a => applyToInvoice_(pay.id, a[0], a[1], user));
  return { id: pay.id, unapplied_c: paymentUnapplied_(pay.id), amount_c: amountC };
}

function applyCredit_(customerId, allocations, user) {
  const list = Object.keys(allocations || {}).map(k => [Number(k), toCents_(allocations[k]) || 0]).filter(a => a[1] > 0);
  if (!list.length) fail_('Enter an amount to apply.');
  validateAllocations_(customerId, list);
  const total = sum_(list, a => a[1]), credit = customerCredit_(customerId);
  if (total > credit) fail_('You entered ' + money_(total) + ' but the account only has ' + money_(credit) + ' of unapplied credit.');
  list.forEach(a => {
    let remaining = a[1];
    Db.where('Payments', p => p.customer_id === customerId && p.status === 'active')
      .sort((x, y) => (x.received_date < y.received_date ? -1 : x.received_date > y.received_date ? 1 : x.id - y.id))
      .forEach(p => {
        if (remaining <= 0) return;
        const free = paymentUnapplied_(p.id);
        if (free <= 0) return;
        const take = Math.min(free, remaining);
        applyToInvoice_(p.id, a[0], take, user);
        remaining -= take;
      });
    if (remaining > 0) fail_('Not enough unapplied credit (short by ' + money_(remaining) + ').');
  });
  return sum_(list, a => a[1]);
}

function unapply_(allocationId, reason, user) {
  const a = Db.must('Allocations', allocationId);
  if (a.status !== 'active') fail_('That has already been unapplied.');
  if (!clean_(reason)) fail_('Give a reason.');
  Db.update('Allocations', a.id, { status: 'reversed', reversed_by: user, reversed_at: now_(), reverse_reason: clean_(reason) });
  audit_(user, 'payment', a.payment_id, 'allocation_reversed', money_(a.amount_c) + ' – ' + reason);
  return a.payment_id;
}

function reversePayment_(paymentId, reason, user) {
  const p = Db.must('Payments', paymentId);
  if (p.status !== 'active') fail_('This payment is already reversed.');
  if (!clean_(reason)) fail_('Give a reason for the reversal.');
  Db.where('Allocations', a => a.payment_id === p.id && a.status === 'active').forEach(a =>
    Db.update('Allocations', a.id, { status: 'reversed', reversed_by: user, reversed_at: now_(), reverse_reason: 'Payment reversed: ' + reason }));
  Db.update('Payments', p.id, { status: 'reversed', reversed_by: user, reversed_at: now_(), reverse_reason: clean_(reason) });
  audit_(user, 'payment', p.id, 'reversed', reason);
}

function editPayment_(paymentId, f, user) {
  const p = Db.must('Payments', paymentId);
  if (p.status !== 'active') fail_('Reversed payments can’t be edited.');
  const next = {
    received_date: f.received_date, amount_c: toCents_(f.amount), payer: clean_(f.payer), reference: clean_(f.reference),
    method: f.method, notes: clean_(f.notes),
  };
  if (!isIso_(next.received_date)) fail_('Enter the date received.');
  if (!next.amount_c || next.amount_c <= 0) fail_('Enter a payment amount above zero.');
  if (!METHODS[next.method]) fail_('Choose a payment method.');
  const applied = p.amount_c - paymentUnapplied_(p.id);
  if (next.amount_c < applied) fail_(money_(applied) + ' of this payment is applied to invoices. Unapply it first to reduce the amount.');
  const changes = Object.keys(next).filter(k => String(p[k]) !== String(next[k])).map(k =>
    k + ': ' + (k === 'amount_c' ? money_(p[k]) + ' → ' + money_(next[k]) : '"' + p[k] + '" → "' + next[k] + '"'));
  if (!changes.length) return;
  Db.update('Payments', p.id, next);
  audit_(user, 'payment', p.id, 'edited', changes.join('; '));
}
