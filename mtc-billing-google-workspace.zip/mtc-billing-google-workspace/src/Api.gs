/** Web app entry point and the API the page calls through google.script.run.api(action, args). */

function doGet() {
  const me = currentUser_();
  if (!me) {
    return HtmlService.createHtmlOutput('<p style="font-family:sans-serif;padding:2rem;max-width:36rem">You don’t have access to MT Creatives Trading billing. ' +
      'Ask the owner to add your Google Workspace email to the <b>Staff</b> tab of the billing sheet.</p>')
      .setTitle('No access').addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('MT Creatives Trading – Billing')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function include(name) { return HtmlService.createHtmlOutputFromFile(name).getContent(); }

/** The signed-in Workspace user, if they are active in the Staff tab. */
function currentUser_() {
  let email = '';
  try { email = (Session.getActiveUser().getEmail() || '').toLowerCase(); } catch (e) { email = ''; }
  if (!email) return null;
  const sh = SpreadsheetApp.getActive().getSheetByName('Staff');
  if (!sh) return null;
  const row = sh.getDataRange().getValues().slice(1).find(r => String(r[0]).trim().toLowerCase() === email &&
    !/^(no|false|0)$/i.test(String(r[2]).trim()));
  return row ? { email, name: String(row[1] || email) } : null;
}

const READ_ACTIONS = {
  bootstrap: bootstrapApi_, dashboard: dashboardApi_, customers: customersApi_, customer: customerApi_, kit: kitApi_,
  statement: statementApi_, invoices: invoicesApi_, invoice: invoiceApi_, generateForm: generateFormApi_,
  emailPreview: emailPreviewApi_, payments: paymentsApi_, payment: paymentApi_, paymentForm: paymentFormApi_,
  followups: followupsApi_, emails: emailsApi_, settings: settingsApi_, history: historyApi_,
  invoicePdf: invoicePdfApi_, proof: proofApi_, invoicesCsv: invoicesCsvApi_, paymentsCsv: paymentsCsvApi_,
};
const WRITE_ACTIONS = {
  saveCustomer: saveCustomerApi_, saveKit: saveKitApi_, addRate: addRateApi_, setOpening: setOpeningApi_,
  applyCredit: applyCreditApi_, generate: generateApi_, saveDraft: saveDraftApi_, reviewLine: reviewLineApi_,
  addAdjustment: addAdjustmentApi_, removeAdjustment: removeAdjustmentApi_, recalc: recalcApi_, deleteDraft: deleteDraftApi_,
  issue: issueApi_, voidInvoice: voidApi_, addCredit: addCreditApi_, sendEmail: sendEmailApi_, recordPayment: recordPaymentApi_,
  editPayment: editPaymentApi_, reversePayment: reversePaymentApi_, unapply: unapplyApi_, saveSettings: saveSettingsApi_,
  runReminders: runRemindersApi_,
};

/** Single entry point. Always returns {ok, data} or {ok:false, error}. */
function api(action, args) {
  const me = currentUser_();
  if (!me) return { ok: false, error: 'You are signed out or not on the Staff list.' };
  args = args || {};
  try {
    let data;
    if (READ_ACTIONS[action]) {
      Db.reset();
      data = READ_ACTIONS[action](args, me);
    } else if (WRITE_ACTIONS[action]) {
      data = withLock_(() => {
        const r = WRITE_ACTIONS[action](args, me.email);
        if (Db.isDirty()) refreshReport_();
        return r;
      });
    } else {
      return { ok: false, error: 'Unknown action.' };
    }
    return { ok: true, data: JSON.parse(JSON.stringify(data === undefined ? null : data)) };
  } catch (e) {
    if (e && e.userError) return { ok: false, error: e.message };
    console.error(e && e.stack || e);
    return { ok: false, error: 'Something went wrong: ' + (e && e.message || e) };
  }
}

const strip_ = r => { const o = Object.assign({}, r); delete o._row; return o; };

// ================================================================= read actions

function setupGaps_() {
  const s = settings_();
  const gaps = companyMissing_(s).map(m => 'Settings are missing ' + m + '.').concat(senderProblems_(s));
  const noEmail = Db.where('Customers', c => c.active && !c.officer_email).length;
  if (noEmail) gaps.push(noEmail + ' account(s) have no billing officer email.');
  const rated = new Set(Db.all('Rates').filter(r => r.monthly_c !== null).map(r => r.kit_id));
  const noRate = Db.where('Kits', k => k.status !== 'ended' && !rated.has(k.id)).length;
  if (noRate) gaps.push(noRate + ' kit(s) have no monthly rate.');
  if (!Db.all('Kits').length) gaps.push('No Starlink kits are recorded yet. Add kits to each account before invoicing.');
  return gaps;
}

function bootstrapApi_(a, me) {
  return { user: me, quarters: recentQuarters_(8, 2), current_quarter: quarterOf_(today_()), today: today_(),
           methods: METHODS, sheet_url: SpreadsheetApp.getActive().getUrl(), company: settings_().company_name };
}

function followups_() {
  const s = settings_();
  const by = {};
  listInvoices_({ state: 'outstanding' }).filter(i => i.overdue).forEach(i => {
    const f = by[i.customer_id] = by[i.customer_id] || { customer_id: i.customer_id, billing_name: i.billing_name,
      officer_name: i.officer_name, officer_email: i.officer_email, paused: i.reminders_paused, overdue_c: 0,
      first_invoice_id: i.id, oldest_due: i.due_date, next_auto: null };
    f.overdue_c += i.balance_c;
    if (i.due_date < f.oldest_due) { f.oldest_due = i.due_date; f.first_invoice_id = i.id; }
    const n = nextAutoStage_(i, s);
    if (n && (!f.next_auto || n.date < f.next_auto.date)) f.next_auto = n;
  });
  const sent = Db.where('EmailLog', l => l.status === 'sent');
  return Object.keys(by).map(k => {
    const f = by[k];
    const last = sent.filter(l => l.customer_id === f.customer_id).map(l => l.sent_at).sort().pop();
    f.last_contact = last || '';
    f.days_overdue = daysBetween_(f.oldest_due, today_());
    f.reminders_on = /^(yes|true|1)$/i.test(s.reminders_enabled);
    return f;
  }).sort((a, b) => (a.last_contact < b.last_contact ? -1 : a.last_contact > b.last_contact ? 1 : b.overdue_c - a.overdue_c));
}

function dashboardApi_(a) {
  const q = a.quarter || quarterOf_(today_());
  const qb = quarterBounds_(q);
  const invs = listInvoices_({ quarter: q });
  const issued = invs.filter(i => i.status === 'issued');
  const invoiced = new Set(invs.filter(i => i.status !== 'void' && i.quarter === q).map(i => i.customer_id));
  return {
    quarter: q, start: qb[0], end: qb[1], invoices: invs, gaps: setupGaps_(), followups: followups_(),
    stats: {
      billed_c: sum_(issued, i => i.total_c), applied_c: sum_(issued, i => i.paid_c), credited_c: sum_(issued, i => i.credited_c),
      outstanding_c: sum_(issued, i => Math.max(i.balance_c, 0)), overdue_c: sum_(issued.filter(i => i.overdue), i => i.balance_c),
      drafts: invs.filter(i => i.status === 'draft').length, count: issued.length,
    },
    not_invoiced: eligibleCustomers_(qb[0], qb[1]).filter(c => !invoiced.has(c.id)).map(c => ({ id: c.id, billing_name: c.billing_name })),
  };
}

function customersApi_() {
  const invs = listInvoices_({});
  return Db.all('Customers').slice().sort((a, b) => a.billing_name.localeCompare(b.billing_name)).map(c => {
    const mine = invs.filter(i => i.customer_id === c.id);
    return Object.assign(strip_(c), {
      kits: Db.where('Kits', k => k.customer_id === c.id && k.status !== 'ended').length,
      outstanding_c: sum_(mine.filter(i => i.state === 'unpaid' || i.state === 'partial'), i => i.balance_c),
      overdue: mine.some(i => i.overdue), credit_c: customerCredit_(c.id), missing: customerMissingForEmail_(c),
    });
  });
}

function customerApi_(a) {
  const c = Db.must('Customers', a.id);
  const t = today_();
  const kits = Db.where('Kits', k => k.customer_id === c.id).map(k => Object.assign(strip_(k), {
    rates: Db.where('Rates', r => r.kit_id === k.id).map(strip_).sort((x, y) => (x.effective_from < y.effective_from ? 1 : -1)),
    current_c: rateOn_(kitRates_(k.id), t),
  }));
  const invs = listInvoices_({ customer_id: c.id });
  const pays = Db.where('Payments', p => p.customer_id === c.id).map(p => Object.assign(strip_(p),
    { unapplied_c: p.status === 'active' ? paymentUnapplied_(p.id) : 0 }))
    .sort((x, y) => (x.received_date < y.received_date ? 1 : -1));
  const numbers = {};
  Db.all('Invoices').forEach(i => { numbers[i.id] = i.number; });
  const emails = Db.where('EmailLog', l => l.customer_id === c.id).map(l => Object.assign(strip_(l), { number: numbers[l.invoice_id] || '' }))
    .sort((x, y) => (x.created_at < y.created_at ? 1 : -1)).slice(0, 30);
  return { customer: strip_(c), kits, invoices: invs, payments: pays, emails, credit_c: customerCredit_(c.id),
           opening: invs.find(i => i.kind === 'opening' && i.status !== 'void') || null,
           outstanding: invs.filter(i => i.state === 'unpaid' || i.state === 'partial'), missing: customerMissingForEmail_(c),
           all_customers: Db.all('Customers').map(x => ({ id: x.id, billing_name: x.billing_name })) };
}

function kitApi_(a) {
  return { kit: a.id ? strip_(Db.must('Kits', a.id)) : null,
           all_customers: Db.all('Customers').map(x => ({ id: x.id, billing_name: x.billing_name })) };
}

function statementApi_(a) {
  const c = Db.must('Customers', a.id);
  return { customer: strip_(c), statement: statement_(c.id, a.start || '', a.end || ''), start: a.start || '', end: a.end || '',
           outstanding: listInvoices_({ customer_id: c.id, state: 'outstanding' }), credit_c: customerCredit_(c.id),
           company: settings_().company_name, today: today_() };
}

function invoicesApi_(a) {
  return { rows: listInvoices_(a), customers: Db.all('Customers').map(x => ({ id: x.id, billing_name: x.billing_name })) };
}

function generateFormApi_() {
  return { customers: Db.where('Customers', c => c.active).map(x => ({ id: x.id, billing_name: x.billing_name }))
    .sort((x, y) => x.billing_name.localeCompare(y.billing_name)) };
}

function invoiceApi_(a) {
  const inv = getInvoice_(a.id);
  const payments = {};
  Db.all('Payments').forEach(p => { payments[p.id] = p; });
  const allocs = Db.where('Allocations', x => x.invoice_id === inv.id).map(x => Object.assign(strip_(x), {
    received_date: payments[x.payment_id].received_date, reference: payments[x.payment_id].reference }));
  const checks = inv.status === 'draft' ? issueChecks_(inv.id) : { blocking: [], warnings: [] };
  const s = settings_();
  const related = Db.where('Invoices', i => i.replaces_invoice_id === inv.id || i.id === inv.replaces_invoice_id)
    .map(i => ({ id: i.id, number: i.number, status: i.status, replaces: i.id === inv.replaces_invoice_id }));
  return {
    invoice: inv, lines: Db.where('InvoiceLines', l => l.invoice_id === inv.id).map(strip_).sort((x, y) => x.sort - y.sort || x.id - y.id),
    allocations: allocs, credits: Db.where('Credits', c => c.invoice_id === inv.id).map(strip_),
    emails: Db.where('EmailLog', l => l.invoice_id === inv.id).map(strip_).sort((x, y) => (x.created_at < y.created_at ? 1 : -1)),
    history: historyFor_('invoice', inv.id), blocking: checks.blocking, warnings: checks.warnings, related,
    next_auto: inv.status === 'issued' ? nextAutoStage_(inv, s) : null, credit_c: customerCredit_(inv.customer_id),
    due_days: s.default_due_days,
  };
}

function emailPreviewApi_(a) {
  const m = buildEmail_(a.id, a.kind);
  return { invoice: m.inv, customer_name: m.cust.billing_name, to: m.to, cc: m.cc, subject: m.subject, body: m.body,
           balance_c: m.balance_c, pdf_name: m.pdf_name, from: m.from, sender_name: m.settings.sender_name,
           reply_to: m.settings.reply_to, problems: emailBlockers_(m, a.kind), kind: a.kind,
           quota: MailApp.getRemainingDailyQuota() };
}

function paymentRows_(a) {
  let start = a.start || '', end = a.end || '';
  if (a.quarter) { const qb = quarterBounds_(a.quarter); start = qb[0]; end = qb[1]; }
  const custs = {}, numbers = {};
  Db.all('Customers').forEach(c => { custs[c.id] = c; });
  Db.all('Invoices').forEach(i => { numbers[i.id] = i.number || ('Draft #' + i.id); });
  return Db.all('Payments').filter(p => (!a.customer_id || p.customer_id === Number(a.customer_id)) &&
      (!start || p.received_date >= start) && (!end || p.received_date <= end) && (!a.status || p.status === a.status))
    .map(p => Object.assign(strip_(p), {
      billing_name: custs[p.customer_id].billing_name, code: custs[p.customer_id].code,
      applied_to: Db.where('Allocations', x => x.payment_id === p.id && x.status === 'active').map(x => numbers[x.invoice_id]).join(', '),
      unapplied_c: p.status === 'active' ? paymentUnapplied_(p.id) : 0,
    }))
    .sort((x, y) => (x.received_date < y.received_date ? 1 : x.received_date > y.received_date ? -1 : y.id - x.id));
}

function paymentsApi_(a) {
  return { rows: paymentRows_(a), customers: Db.all('Customers').map(x => ({ id: x.id, billing_name: x.billing_name })) };
}

function paymentFormApi_(a) {
  const customers = Db.all('Customers').map(x => ({ id: x.id, billing_name: x.billing_name })).sort((x, y) => x.billing_name.localeCompare(y.billing_name));
  if (!a.customer_id) return { customers };
  const c = Db.must('Customers', a.customer_id);
  return { customers, customer: strip_(c), outstanding: listInvoices_({ customer_id: c.id, state: 'outstanding' }) };
}

function paymentApi_(a) {
  const p = Db.must('Payments', a.id);
  const numbers = {};
  Db.all('Invoices').forEach(i => { numbers[i.id] = i.number; });
  return { payment: Object.assign(strip_(p), { billing_name: Db.must('Customers', p.customer_id).billing_name }),
           allocations: Db.where('Allocations', x => x.payment_id === p.id).map(x => Object.assign(strip_(x), { number: numbers[x.invoice_id] })),
           unapplied_c: p.status === 'active' ? paymentUnapplied_(p.id) : 0, history: historyFor_('payment', p.id),
           has_outstanding: listInvoices_({ customer_id: p.customer_id, state: 'outstanding' }).length > 0 };
}

function followupsApi_() { return { followups: followups_() }; }

function emailsApi_() {
  const numbers = {}, names = {};
  Db.all('Invoices').forEach(i => { numbers[i.id] = i.number; });
  Db.all('Customers').forEach(c => { names[c.id] = c.billing_name; });
  return { rows: Db.all('EmailLog').map(l => Object.assign(strip_(l), { number: numbers[l.invoice_id] || '', billing_name: names[l.customer_id] }))
    .sort((x, y) => (x.created_at < y.created_at ? 1 : -1)).slice(0, 300) };
}

function settingsApi_() {
  const s = settings_();
  return { settings: s, problems: senderProblems_(s), from: senderEmail_(), trigger: reminderTriggerInstalled_(),
           quota: MailApp.getRemainingDailyQuota() };
}

function historyFor_(entity, id) {
  const sh = SpreadsheetApp.getActive().getSheetByName('Audit');
  return sh.getDataRange().getValues().slice(1).filter(r => r[2] === entity && Number(r[3]) === Number(id))
    .map(r => ({ at: fmtStamp_(r[0]), user: r[1], action: r[4], detail: r[5] })).reverse();
}
function fmtStamp_(v) { return v instanceof Date ? Utilities.formatDate(v, TZ, 'yyyy-MM-dd HH:mm:ss') : String(v); }

function historyApi_() {
  const sh = SpreadsheetApp.getActive().getSheetByName('Audit');
  return { rows: sh.getDataRange().getValues().slice(1).slice(-500).reverse()
    .map(r => ({ at: fmtStamp_(r[0]), user: r[1], entity: r[2], entity_id: r[3], action: r[4], detail: r[5] })) };
}

function invoicePdfApi_(a) {
  const inv = Db.must('Invoices', a.id);
  const blob = invoicePdfBlob_(inv);
  return { name: inv.number + '.pdf', mime: 'application/pdf', base64: Utilities.base64Encode(blob.getBytes()) };
}

function proofApi_(a) {
  const p = Db.must('Payments', a.id);
  if (!p.proof_file_id) fail_('No proof of payment was attached.');
  let blob;
  try { blob = DriveApp.getFileById(p.proof_file_id).getBlob(); } catch (e) { fail_('The proof file is missing from Google Drive.'); }
  return { name: p.proof_name || 'proof', mime: blob.getContentType(), base64: Utilities.base64Encode(blob.getBytes()) };
}

function csv_(header, rows) {
  const cell = v => { const s = String(v === null || v === undefined ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
  return '\ufeff' + [header].concat(rows).map(r => r.map(cell).join(',')).join('\r\n');
}

const STATE_LABELS = { draft: 'Draft', unpaid: 'Unpaid', partial: 'Partly paid', paid: 'Paid', void: 'Void' };

function invoiceReportRows_(rows) {
  return rows.map(r => [r.number || 'DRAFT-' + r.id, r.customer_code, r.billing_name, r.kind, r.period_start, r.period_end,
    r.quarter || (r.kind === 'invoice' ? 'custom' : ''), r.invoice_date, r.due_date, STATE_LABELS[r.state], r.overdue ? 'yes' : 'no',
    plainMoney_(r.total_c), plainMoney_(r.paid_c), plainMoney_(r.credited_c), plainMoney_(r.state === 'void' || r.state === 'draft' ? 0 : r.balance_c)]);
}

function invoicesCsvApi_(a) {
  return { name: 'invoices-' + today_() + '.csv', mime: 'text/csv',
           base64: Utilities.base64Encode(csv_(REPORT_HEADERS, invoiceReportRows_(listInvoices_(a))), Utilities.Charset.UTF_8) };
}

function paymentsCsvApi_(a) {
  const rows = paymentRows_(a).map(p => [p.id, p.received_date, p.code, p.billing_name, plainMoney_(p.amount_c), p.applied_to,
    plainMoney_(p.unapplied_c), p.payer, p.reference, METHODS[p.method] || p.method, p.status, p.notes, p.created_by, p.created_at]);
  return { name: 'payments-' + today_() + '.csv', mime: 'text/csv', base64: Utilities.base64Encode(csv_(
    ['Payment ID', 'Date received', 'Account code', 'Customer', 'Amount AUD', 'Applied to', 'Unapplied AUD', 'Payer', 'Reference',
     'Method', 'Status', 'Notes', 'Recorded by', 'Recorded at'], rows), Utilities.Charset.UTF_8) };
}

// ================================================================= write actions

function saveCustomerApi_(a, user) {
  const f = {};
  ['code', 'billing_name', 'school_division', 'location', 'officer_name', 'officer_email', 'cc_email', 'notes'].forEach(k => { f[k] = clean_(a[k]); });
  f.code = f.code.toUpperCase().replace(/\s+/g, '-');
  f.reminders_paused = !!a.reminders_paused;
  f.active = a.active === undefined ? true : !!a.active;
  if (!f.code || !f.billing_name) fail_('Account code and billing name are required.');
  splitAddrs_(f.officer_email).concat(splitAddrs_(f.cc_email)).forEach(x => { if (!EMAIL_RE.test(x)) fail_('"' + x + '" doesn’t look like an email address.'); });
  const id = a.id ? Number(a.id) : null;
  if (Db.where('Customers', c => c.code === f.code && c.id !== id).length) fail_('Account code ' + f.code + ' is already used.');
  if (id) {
    const old = Db.must('Customers', id);
    const changes = Object.keys(f).filter(k => String(old[k]) !== String(f[k])).map(k => k + ': "' + old[k] + '" → "' + f[k] + '"');
    Db.update('Customers', id, Object.assign(f, { updated_at: now_() }));
    if (changes.length) audit_(user, 'customer', id, 'edited', changes.join('; '));
    return { message: 'Account saved.', redirect: '#/customer/' + id };
  }
  const c = Db.insert('Customers', Object.assign(f, { created_at: now_(), updated_at: now_() }));
  audit_(user, 'customer', c.id, 'created', f.billing_name);
  return { message: 'Account added.', redirect: '#/customer/' + c.id };
}

function saveKitApi_(a, user) {
  const f = { kit_ref: clean_(a.kit_ref), service_location: clean_(a.service_location), plan: clean_(a.plan), status: a.status,
              notes: clean_(a.notes), billing_start: clean_(a.billing_start), billing_end: clean_(a.billing_end),
              customer_id: Number(a.customer_id) };
  if (!f.kit_ref) fail_('Enter the kit reference.');
  if (KIT_STATUSES.indexOf(f.status) < 0) fail_('Choose a service status.');
  if (f.billing_start && !isIso_(f.billing_start)) fail_('Enter a valid billing start date.');
  if (f.billing_end && !isIso_(f.billing_end)) fail_('Enter a valid billing end date.');
  if (f.billing_start && f.billing_end && f.billing_end < f.billing_start) fail_('The billing end date is before the start date.');
  Db.must('Customers', f.customer_id);
  if (a.id) {
    const old = Db.must('Kits', a.id);
    const changes = Object.keys(f).filter(k => String(old[k]) !== String(f[k])).map(k => k + ': "' + old[k] + '" → "' + f[k] + '"');
    Db.update('Kits', a.id, f);
    if (changes.length) audit_(user, 'kit', Number(a.id), 'edited', changes.join('; '));
    return { message: f.customer_id !== old.customer_id ? 'Kit saved and moved to another account.' : 'Kit saved.',
             redirect: '#/customer/' + f.customer_id };
  }
  const k = Db.insert('Kits', Object.assign(f, { created_at: now_() }));
  audit_(user, 'kit', k.id, 'created', f.kit_ref);
  const rate = toCents_(a.monthly_rate);
  if (rate !== null) {
    if (rate < 0) fail_('The monthly charge can’t be negative.');
    Db.insert('Rates', { kit_id: k.id, effective_from: f.billing_start || today_(), monthly_c: rate, note: 'Initial rate', created_by: user, created_at: now_() });
  }
  return { message: 'Kit added.', redirect: '#/customer/' + f.customer_id };
}

function addRateApi_(a, user) {
  const k = Db.must('Kits', a.kit_id);
  const c = toCents_(a.monthly_rate);
  if (c === null || c < 0) fail_('Enter the monthly charge.');
  if (!isIso_(a.effective_from)) fail_('Enter the date the rate starts.');
  const existing = Db.where('Rates', r => r.kit_id === k.id && r.effective_from === a.effective_from)[0];
  if (existing) Db.update('Rates', existing.id, { monthly_c: c, note: clean_(a.note) });
  else Db.insert('Rates', { kit_id: k.id, effective_from: a.effective_from, monthly_c: c, note: clean_(a.note), created_by: user, created_at: now_() });
  audit_(user, 'kit', k.id, 'rate_set', money_(c) + '/month from ' + a.effective_from);
  return { message: 'Rate ' + money_(c) + ' a month from ' + fmtDate_(a.effective_from) + ' saved. Existing drafts keep their figures until you recalculate them.' };
}

function setOpeningApi_(a, user) {
  setOpening_(Number(a.customer_id), toCents_(a.amount) || 0, a.as_of, user);
  return { message: 'Opening balance saved.' };
}

function applyCreditApi_(a, user) {
  const total = applyCredit_(Number(a.customer_id), a.apply, user);
  return { message: 'Applied ' + money_(total) + ' of credit.' };
}

function generateApi_(a, user) {
  if (a.mode === 'quarter_all') return { result: generateQuarter_(a.quarter, user) };
  const cid = Number(a.customer_id);
  if (!cid) fail_('Choose an account.');
  let ps, pe, q = '';
  if (a.mode === 'quarter_one') { q = a.quarter; const qb = quarterBounds_(q); ps = qb[0]; pe = qb[1]; }
  else { ps = a.period_start; pe = a.period_end; }
  if (a.mode === 'custom' && !a.confirm_overlap && isIso_(ps) && isIso_(pe)) {
    const ov = overlapping_(cid, ps, pe);
    if (ov.length) return { overlap: ov.map(o => ({ label: o.number || 'Draft #' + o.id, period: fmtPeriod_(o.period_start, o.period_end), status: o.status })), args: a };
  }
  const r = createDraft_(cid, ps, pe, q, user, !!a.confirm_overlap);
  return { message: 'Draft created. Review it, then issue.', warnings: r.warnings, redirect: '#/invoice/' + r.id };
}

function saveDraftApi_(a, user) { saveDraft_(Number(a.id), clean_(a.due_date), a.notes, user); return { message: 'Draft saved.' }; }
function reviewLineApi_(a, user) { reviewLine_(Number(a.id), Number(a.line_id), toCents_(a.amount), a.reason, user); return { message: 'Part month confirmed.' }; }
function addAdjustmentApi_(a, user) {
  let c = toCents_(a.amount);
  if (c === null) fail_('Enter an amount.');
  if (a.direction === 'discount') c = -Math.abs(c);
  addAdjustment_(Number(a.id), a.description, c, a.reason, user);
  return { message: 'Adjustment added.' };
}
function removeAdjustmentApi_(a, user) { removeAdjustment_(Number(a.id), Number(a.line_id), user); return { message: 'Adjustment removed.' }; }
function recalcApi_(a, user) { return { message: 'Charges recalculated from current kits and rates.', warnings: recalcDraft_(Number(a.id), user) }; }
function deleteDraftApi_(a, user) { const cid = deleteDraft_(Number(a.id), user); return { message: 'Draft deleted.', redirect: '#/customer/' + cid }; }

function issueApi_(a, user) {
  const ids = (Array.isArray(a.ids) ? a.ids : [a.ids]).map(Number).filter(Boolean);
  if (!ids.length) fail_('Tick the drafts you want to issue.');
  const done = [], failed = [];
  ids.forEach(id => {
    try { done.push(issueInvoice_(id, user)); } catch (e) {
      if (!e.userError) throw e;
      const inv = Db.get('Invoices', id);
      failed.push((inv ? (Db.get('Customers', inv.customer_id) || {}).billing_name : 'Invoice ' + id) + ': ' + e.message);
    }
  });
  if (!done.length && ids.length === 1) fail_(failed[0].split(': ').slice(1).join(': '));
  return { message: done.length ? 'Issued ' + done.join(', ') + '.' + (ids.length === 1 ? ' The PDF is saved in Google Drive.' : '') : '',
           errors: failed.map(f => 'Not issued – ' + f) };
}

function voidApi_(a, user) {
  const r = voidInvoice_(Number(a.id), a.reason, !!a.reissue, user);
  let msg = 'Invoice voided.';
  if (r.returned) msg += ' ' + money_(r.returned) + ' of payments moved back to the account’s credit.';
  if (r.newId) return { message: msg + ' A replacement draft was created – check it and issue.', redirect: '#/invoice/' + r.newId };
  return { message: msg };
}

function addCreditApi_(a, user) {
  const n = addCredit_(Number(a.id), toCents_(a.amount), a.reason, user);
  return { message: 'Credit ' + n + ' recorded.' };
}

function sendEmailApi_(a, user) {
  const r = sendInvoiceEmail_(Number(a.id), a.kind, user, 'manual', 'manual', a.expected_balance);
  if (!r.ok) fail_(r.message);
  return { message: r.message, redirect: '#/invoice/' + a.id };
}

function recordPaymentApi_(a, user) {
  const r = recordPayment_(a, user);
  if (r.duplicates) return { duplicates: r.duplicates };
  return { message: 'Payment of ' + money_(r.amount_c) + ' recorded.' + (r.unapplied_c ? ' ' + money_(r.unapplied_c) + ' is held as credit on the account.' : ''),
           redirect: '#/payment/' + r.id };
}

function editPaymentApi_(a, user) { editPayment_(Number(a.id), a, user); return { message: 'Payment updated. The change is in the history below.' }; }
function reversePaymentApi_(a, user) { reversePayment_(Number(a.id), a.reason, user); return { message: 'Payment reversed. Invoice balances have been restored.' }; }
function unapplyApi_(a, user) { unapply_(Number(a.allocation_id), a.reason, user); return { message: 'Unapplied. The amount is back in the account’s credit.' }; }

const SETTING_KEYS = ['company_name', 'company_address', 'company_phone', 'company_email', 'company_reg', 'bank_account_name',
  'bank_name', 'bank_branch', 'bank_account_number', 'bank_swift', 'payment_instructions', 'sender_name', 'reply_to',
  'invoice_prefix', 'default_due_days', 'reminder_offsets'];

function saveSettingsApi_(a, user) {
  const next = {};
  SETTING_KEYS.forEach(k => { next[k] = clean_(a[k]); });
  if (!/^\d+$/.test(next.default_due_days)) fail_('Days until due must be a whole number.');
  const offsets = parseOffsets_(next.reminder_offsets);
  if (!offsets.length) fail_('Add at least one reminder timing.');
  next.reminder_offsets = offsets.join(', ');
  next.invoice_prefix = next.invoice_prefix.toUpperCase().replace(/\s+/g, '') || 'MTC';
  let enable = !!a.reminders_enabled;
  const warnings = [];
  if (next.reply_to && !EMAIL_RE.test(next.reply_to)) fail_('The reply-to address doesn’t look like an email address.');
  if (enable && senderProblems_(next).length) {
    enable = false;
    warnings.push('Automatic reminders stay off until the sender is set up: ' + senderProblems_(next).join(' '));
  }
  next.reminders_enabled = enable ? 'yes' : 'no';
  const old = settings_();
  const changed = Object.keys(next).filter(k => old[k] !== next[k]);
  Object.keys(next).forEach(k => { if (old[k] !== next[k]) setSetting_(k, next[k]); });
  setReminderTrigger_(enable);
  if (changed.length) audit_(user, 'settings', '', 'edited', changed.join(', '));
  return { message: 'Settings saved.' + (enable ? ' Automatic reminders are on and run every hour.' : ''), warnings };
}

function runRemindersApi_(a, user) {
  const r = runAutoReminders_(user);
  if (r.disabled) fail_('Automatic reminders are off. Turn them on in Settings first.');
  return { message: 'Reminder run: ' + r.sent.length + ' sent, ' + r.skipped.length + ' skipped, ' + r.failed.length + ' failed.',
           errors: r.failed.map(f => f[0] + ': ' + f[1]), redirect: '#/emails' };
}
