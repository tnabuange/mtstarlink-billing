/**
 * Sheet tables. Each call to the app reads a tab once, keeps it in memory for that call,
 * and writes changes straight back. All writes run inside withLock_() so two people (or the
 * hourly reminder trigger) can't change the same data at once.
 *
 * In memory, money columns `x_aud` become integer cents named `x_c`.
 */
const Db = (() => {
  let cache = {};
  let dirty = false;

  const ss = () => SpreadsheetApp.getActive();
  const sheet = name => {
    const sh = ss().getSheetByName(name);
    if (!sh) fail_('The "' + name + '" tab is missing. Run MTC Billing → First-time setup from the sheet menu.');
    return sh;
  };
  const isMoney = col => /_aud$/.test(col);
  const memKey = col => (isMoney(col) ? col.replace(/_aud$/, '_c') : col);
  const isNumId = col => col === 'id' || /_id$/.test(col) && col !== 'pdf_file_id' && col !== 'proof_file_id' || col === 'sort';

  function fromCell(col, v) {
    if (isMoney(col)) return v === '' || v === null ? null : toCents_(v);
    if (isNumId(col)) return v === '' || v === null ? null : Number(v);
    if (BOOL_COLS.indexOf(col) >= 0) return v === true || /^(yes|true|y|1)$/i.test(String(v).trim());
    if (v instanceof Date) {
      return DATE_COLS.indexOf(col) >= 0 ? Utilities.formatDate(v, TZ, 'yyyy-MM-dd') : Utilities.formatDate(v, TZ, 'yyyy-MM-dd HH:mm:ss');
    }
    return v === null || v === undefined ? '' : String(v).trim();
  }

  function toCell(col, v) {
    if (isMoney(col)) return v === null || v === undefined || v === '' ? '' : v / 100;
    if (BOOL_COLS.indexOf(col) >= 0) return v ? 'yes' : 'no';
    if (v === null || v === undefined) return '';
    return textCell_(v);
  }

  function load(name) {
    if (cache[name]) return cache[name];
    const sh = sheet(name);
    const values = sh.getDataRange().getValues();
    const head = (values[0] || []).map(h => String(h).trim());
    const cols = SCHEMA[name];
    const rows = [];
    for (let i = 1; i < values.length; i++) {
      const raw = values[i];
      if (raw.every(v => v === '' || v === null)) continue;
      const rec = { _row: i + 1 };
      cols.forEach(col => {
        const j = head.indexOf(col);
        rec[memKey(col)] = fromCell(col, j >= 0 ? raw[j] : '');
      });
      rows.push(rec);
    }
    cache[name] = { rows, head };
    return cache[name];
  }

  function rowArray(name, rec, head) {
    return head.map(h => (SCHEMA[name].indexOf(h) >= 0 ? toCell(h, rec[memKey(h)]) : ''));
  }

  return {
    reset() { cache = {}; dirty = false; },
    isDirty() { return dirty; },
    all(name) { return load(name).rows; },
    where(name, fn) { return load(name).rows.filter(fn); },
    get(name, id) { return load(name).rows.find(r => r.id === Number(id)) || null; },
    must(name, id) {
      const r = this.get(name, id);
      if (!r) fail_('That record no longer exists. Reload the page.');
      return r;
    },
    insert(name, obj) {
      const t = load(name);
      const rec = Object.assign({}, obj);
      if (SCHEMA[name].indexOf('id') === 0) rec.id = t.rows.reduce((m, r) => Math.max(m, r.id || 0), 0) + 1;
      const sh = sheet(name);
      sh.appendRow(rowArray(name, rec, t.head));
      rec._row = sh.getLastRow();
      t.rows.push(rec);
      dirty = true;
      return rec;
    },
    update(name, id, changes) {
      const t = load(name);
      const rec = t.rows.find(r => r.id === Number(id));
      if (!rec) fail_('That record no longer exists. Reload the page.');
      Object.assign(rec, changes);
      sheet(name).getRange(rec._row, 1, 1, t.head.length).setValues([rowArray(name, rec, t.head)]);
      dirty = true;
      return rec;
    },
    remove(name, id) {
      const t = load(name);
      const rec = t.rows.find(r => r.id === Number(id));
      if (!rec) return;
      sheet(name).deleteRow(rec._row);
      delete cache[name]; // row numbers shifted
      dirty = true;
    },
  };
})();

function withLock_(fn) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) fail_('Someone else is saving changes. Try again in a moment.');
  try {
    Db.reset(); // read fresh data inside the lock
    return fn();
  } finally {
    SpreadsheetApp.flush();
    lock.releaseLock();
  }
}

// ------------------------------------------------------------------ settings, audit

function settings_() {
  const out = {};
  SETTINGS_DEFAULTS.forEach(s => { out[s[0]] = s[1]; });
  const sh = SpreadsheetApp.getActive().getSheetByName('Settings');
  if (sh) {
    sh.getDataRange().getValues().slice(1).forEach(r => {
      if (r[0] !== '') out[String(r[0]).trim()] = r[1] === null || r[1] === undefined ? '' : String(r[1]).trim();
    });
  }
  return out;
}

function setSetting_(key, value) {
  const sh = SpreadsheetApp.getActive().getSheetByName('Settings');
  const vals = sh.getDataRange().getValues();
  const v = textCell_(String(value));
  for (let i = 1; i < vals.length; i++) {
    if (String(vals[i][0]).trim() === key) {
      sh.getRange(i + 1, 2).setValue(v);
      return;
    }
  }
  const about = (SETTINGS_DEFAULTS.find(s => s[0] === key) || [])[2] || '';
  sh.appendRow([key, v, about]);
}

function audit_(user, entity, entityId, action, detail) {
  const sh = SpreadsheetApp.getActive().getSheetByName('Audit');
  sh.appendRow([textCell_(now_()), user || 'system', entity, entityId === null || entityId === undefined ? '' : entityId, action,
                textCell_(detail || '')]);
}

/**
 * Text that looks like a number, date or formula is stored with a leading apostrophe, so Sheets keeps it
 * exactly as typed (references like 000123 keep their zeros, dates stay yyyy-mm-dd, "=..." never runs).
 */
function textCell_(v) {
  if (typeof v === 'string' && /^[=+\-@\d.]/.test(v)) return "'" + v;
  return v;
}

function nextSeq_(name) {
  const props = PropertiesService.getScriptProperties();
  const n = Number(props.getProperty('seq_' + name) || '1');
  props.setProperty('seq_' + name, String(n + 1));
  return n;
}
