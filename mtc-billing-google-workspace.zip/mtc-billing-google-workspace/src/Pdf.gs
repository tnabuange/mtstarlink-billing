/** Invoice PDFs, written once at issue into a private Drive folder. */

function folder_(propKey, name) {
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty(propKey);
  if (id) {
    try { return DriveApp.getFolderById(id); } catch (e) { /* deleted: make a new one */ }
  }
  const f = DriveApp.createFolder(name);
  props.setProperty(propKey, f.getId());
  return f;
}
function invoiceFolder_() { return folder_('invoice_folder_id', 'MTC Billing – Invoice PDFs'); }
function evidenceFolder_() { return folder_('evidence_folder_id', 'MTC Billing – Payment evidence (private)'); }

function invoiceHtml_(inv, cust, lines, s) {
  const e = htmlEsc_;
  const ink = '#14324a', lagoon = '#0b6e78', soft = '#4a5e6b', rule = '#c9d3d8';
  const company = [s.company_address, s.company_phone, s.company_email, s.company_reg ? 'Reg. ' + s.company_reg : '']
    .filter(Boolean).map(x => e(x).replace(/\n/g, '<br>')).join('<br>');
  const billTo = [cust.billing_name, cust.school_division, cust.location, cust.officer_name ? 'Attn: ' + cust.officer_name : '', cust.officer_email]
    .filter(Boolean).map(e).join('<br>');
  const rows = lines.map(l => '<tr>' +
    '<td style="padding:6px 4px 6px 0;border-bottom:1px solid ' + rule + '">' + e(l.description) +
      (l.line_type === 'adjustment' && l.reason ? '<br><span style="color:' + soft + ';font-size:8.5pt">Reason: ' + e(l.reason) + '</span>' : '') + '</td>' +
    '<td style="padding:6px 4px;border-bottom:1px solid ' + rule + '">' + e(l.period_start ? fmtPeriod_(l.period_start, l.period_end) : '') + '</td>' +
    '<td style="padding:6px 4px;border-bottom:1px solid ' + rule + ';text-align:right">' + (l.rate_c !== null && l.line_type === 'charge' ? money_(l.rate_c) : '') + '</td>' +
    '<td style="padding:6px 4px;border-bottom:1px solid ' + rule + '">' + e(l.months) + '</td>' +
    '<td style="padding:6px 0 6px 4px;border-bottom:1px solid ' + rule + ';text-align:right">' + money_(l.amount_c) + '</td></tr>').join('');
  const bank = [['Account name', s.bank_account_name], ['Bank', s.bank_name], ['Branch / BSB', s.bank_branch],
                ['Account number', s.bank_account_number], ['SWIFT', s.bank_swift]].filter(b => b[1])
    .map(b => '<tr><td style="color:' + soft + ';padding:1px 14px 1px 0;font-size:8.5pt">' + b[0] + '</td><td>' + e(b[1]) + '</td></tr>').join('');
  const meta = [['Invoice number', '<b>' + e(inv.number) + '</b>'], ['Invoice date', fmtDate_(inv.invoice_date)],
                ['Due date', '<b>' + fmtDate_(inv.due_date) + '</b>'], ['Period covered', fmtPeriod_(inv.period_start, inv.period_end)]]
    .map(m => '<tr><td style="color:' + soft + ';font-size:8.5pt;padding:2px 16px 2px 0">' + m[0] + '</td><td style="text-align:right">' + m[1] + '</td></tr>').join('');

  return '<html><head><meta charset="utf-8"><style>' +
    'body{font-family:Arial,Helvetica,sans-serif;font-size:9.5pt;color:' + ink + ';margin:0}' +
    'table{border-collapse:collapse}th{text-align:left;font-size:9pt;padding:6px 4px;border-bottom:1.5px solid ' + ink + '}' +
    '</style></head><body>' +
    '<table style="width:100%"><tr><td style="vertical-align:top">' +
      '<div style="font-size:20pt;font-weight:bold;color:' + lagoon + '">' + e(s.company_name) + '</div>' +
      '<div style="color:' + soft + ';font-size:8.5pt;margin-top:4px">' + company + '</div></td>' +
      '<td style="vertical-align:top;text-align:right"><table style="margin-left:auto">' + meta + '</table></td></tr></table>' +
    '<div style="font-size:15pt;font-weight:bold;margin-top:28px">Invoice</div>' +
    '<div style="color:' + soft + ';font-size:8.5pt;margin-top:4px">Bill to</div><div>' + billTo + '</div>' +
    '<table style="width:100%;margin-top:22px"><thead><tr><th style="padding-left:0">Description</th><th>Dates covered</th>' +
      '<th style="text-align:right">Rate / month</th><th>Months</th><th style="text-align:right;padding-right:0">Amount</th></tr></thead><tbody>' + rows +
      '<tr><td></td><td></td><td></td><td style="padding:7px 4px;border-top:1.5px solid ' + ink + ';font-weight:bold">Total</td>' +
      '<td style="padding:7px 0 7px 4px;border-top:1.5px solid ' + ink + ';text-align:right;font-weight:bold">' + money_(inv.total_c) + '</td></tr>' +
    '</tbody></table>' +
    '<div style="color:' + soft + ';font-size:8.5pt;margin-top:4px">All amounts are in Australian dollars (AUD).</div>' +
    '<div style="font-weight:bold;font-size:10.5pt;margin-top:26px">How to pay</div>' +
    (bank ? '<table style="margin-top:4px">' + bank + '</table>' : '') +
    '<div style="margin-top:6px">Please use ' + e(inv.number) + ' as the payment reference.</div>' +
    (s.payment_instructions ? '<div style="margin-top:6px">' + e(s.payment_instructions).replace(/\n/g, '<br>') + '</div>' : '') +
    (inv.notes ? '<div style="margin-top:18px;color:' + soft + ';font-size:8.5pt">' + e(inv.notes).replace(/\n/g, '<br>') + '</div>' : '') +
    '</body></html>';
}

function writeInvoicePdf_(invId) {
  const inv = Db.must('Invoices', invId);
  const cust = Db.must('Customers', inv.customer_id);
  const lines = Db.where('InvoiceLines', l => l.invoice_id === inv.id).sort((a, b) => a.sort - b.sort || a.id - b.id);
  const html = invoiceHtml_(inv, cust, lines, settings_());
  const pdf = HtmlService.createHtmlOutput(html).getBlob().getAs('application/pdf').setName(inv.number + '.pdf');
  return invoiceFolder_().createFile(pdf).getId();
}

function invoicePdfBlob_(inv) {
  if (!inv.pdf_file_id) fail_('This invoice has no PDF yet. Drafts get one when they’re issued.');
  try {
    return DriveApp.getFileById(inv.pdf_file_id).getBlob().setName(inv.number + '.pdf');
  } catch (e) {
    fail_('The PDF for ' + inv.number + ' is missing from Google Drive (was it deleted?). Restore it from Drive’s bin.');
  }
}
