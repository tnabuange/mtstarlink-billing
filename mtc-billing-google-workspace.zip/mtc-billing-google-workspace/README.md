# MT Creatives Trading – Starlink Billing & Payments (Google Workspace edition)

This is the same billing system as the server version, rebuilt to run entirely inside your Google Workspace:

| Part | Where it lives |
|---|---|
| All raw data | **One Google Sheet**, one tab per kind of record |
| The billing app (dashboard, invoices, payments, reminders) | **Apps Script web app**, opened from a bookmark on your phone or computer |
| Sign-in | Your **Google Workspace accounts**. Only people listed in the Staff tab get in |
| Invoice and reminder emails | **Gmail**, sent from the account that deploys the app |
| Invoice PDFs and payment evidence | **Private Google Drive folders** |
| Automatic reminders and weekly backups | **Apps Script timers** (triggers) |

There's no server to rent, nothing to install, and no password stored anywhere: Google handles sign-in and email.

## Contents

1. [Set it up (about 20 minutes)](#1-set-it-up)
2. [Fill in your details](#2-fill-in-your-details)
3. [The raw data sheet](#3-the-raw-data-sheet)
4. [Emails and automatic reminders](#4-emails-and-automatic-reminders)
5. [Backups and restoring](#5-backups-and-restoring)
6. [Updating the app](#6-updating-the-app)
7. [How the billing rules work](#7-how-the-billing-rules-work)
8. [What was tested, and what to check yourself](#8-what-was-tested-and-what-to-check-yourself)
9. [Limits to know about](#9-limits-to-know-about)

---

## 1. Set it up

**Which account to use:** set it up while signed in to the Google account the emails should come **from**, for example a shared `billing@yourdomain` mailbox or your own work account. Reminders are sent from this account, and the Sheet and Drive folders are owned by it.

### Option A – copy and paste (no tools needed)

1. In Google Drive, create a new **Google Sheet** and name it, for example, *MTC Billing – Data*.
2. In the Sheet, open **Extensions → Apps Script**. A new tab opens with a file called `Code.gs`. Delete everything in it.
3. In the Apps Script editor, open **Project Settings** (the gear icon). Tick **Show "appsscript.json" manifest file in editor**. Go back to the **Editor** (the `< >` icon), open `appsscript.json`, and replace its contents with `src/appsscript.json` from this folder.
4. Create the script files. Click **+ → Script**, type the name without `.gs`, and paste in the matching file from `src/`. Rename `Code.gs` to `Config` and use it for the first one.
   `Config`, `Util`, `Db`, `Billing`, `Payments`, `Pdf`, `Email`, `Api`, `Setup`
5. Create the HTML files. Click **+ → HTML**, type the name without `.html`, and paste in the matching file:
   `Index`, `Styles`, `App`
6. Click **Save** (the disk icon).

### Option B – with `clasp`, Google's command-line tool (faster if you're comfortable with a terminal)

```bash
npm install -g @google/clasp
clasp login                                  # sign in as the account that will send the emails
cd src
clasp create --type sheets --title "MTC Billing – Data"   # creates the Sheet and its script
clasp push                                   # uploads all 13 files
clasp open                                   # opens the editor
```

Before `clasp push`, turn on the Apps Script API at https://script.google.com/home/usersettings.

### Then, for both options

7. **Run the setup.** In the editor's toolbar, choose the function **`setup`** and click **Run**. Google asks for permission. Click **Review permissions**, choose your account, and allow access.
   - If it says *"Google hasn't verified this app"*, that's normal for a script you wrote yourself. Click **Advanced → Go to (project name)**.
   - The permissions requested are: this spreadsheet, Drive (for the PDF and evidence folders), sending email as you, running timers, and seeing who is signed in.

   Setup is safe to run again. It does the following:
   - creates the tabs and sets the time zone to Pacific/Tarawa;
   - adds the 13 starter accounts and adds you to the Staff tab;
   - creates three private Drive folders: *MTC Billing – Invoice PDFs*, *MTC Billing – Payment evidence (private)* and *MTC Billing – Backups*;
   - switches on weekly backups.
8. **Publish the web app.** Click **Deploy → New deployment**, then the gear next to *Select type* → **Web app**. Set:
   - **Execute as:** *Me*
   - **Who has access:** *Anyone within [your organisation]*

   Click **Deploy**, then copy the **Web app URL**. That's the address of your billing app. Bookmark it, and add it to your phone's home screen.
9. **Add your colleagues.** In the Sheet's **Staff** tab, add a row for each person: their Workspace email, name, and `yes` in the active column. To remove someone, change their `yes` to `no`. Staff don't need access to the Sheet itself; they only need the app link. Share the Sheet only with people who should see the raw data.
10. Reload the Sheet. A **MTC Billing** menu appears with these items: *Open the billing app*, *Refresh the Invoice balances tab*, *Run automatic reminders now*, *Back up now* and *First-time setup*.

## 2. Fill in your details

The dashboard lists anything still missing. The app also won't issue an invoice or send an email until the information it needs is there.

1. **Settings** (in the app): company address and contact details, bank details or payment instructions, invoice number prefix (`MTC` gives `MTC-2026-0001`), days until due, and your **sender name** for emails.
2. **Accounts:** for each account, the billing officer's name and email, an optional CC, the school or division, and the location.
3. **Kits:** on each account, add its Starlink kits with the reference, plan, location, billing start date and monthly charge in AUD.
4. **Opening balances (optional):** on the account page, under **Opening balance**.
5. **Test email:** temporarily put your own address as an account's officer, issue a test invoice and send it to yourself. That checks the PDF and email look right.
6. **Automatic reminders:** tick **Send automatic reminders** in Settings when ready. This installs the hourly timer. Reminders stay off until you do.

**Billing KGV and EBS separately:** add a new account (for example "EBS"), open each kit that belongs to it, and move it using the kit's **Billing account** field. Then rename the original account. Invoices already issued are not changed.

## 3. The raw data sheet

Every record is a row. Column names are the same in every tab: `id` numbers each row, and `customer_id`, `invoice_id` and `payment_id` point at rows in other tabs. Amounts are in columns ending `_aud`, stored as plain numbers, so `SUM`, filters and pivot tables work. Dates are text in `yyyy-mm-dd` form (Pacific/Tarawa).

| Tab | One row per… | Edit directly in the Sheet? |
|---|---|---|
| **Customers** | billing account | Yes, it's fine (the app picks it up immediately) |
| **Kits** | Starlink kit | Yes. Keep dates as `2026-07-01`; a date typed as `01/07/2026` is also understood |
| **Rates** | monthly charge from a date (the rate history) | Yes: add a row to change a rate from a date |
| **Settings** | setting (`key`, `value`, explanation) | Yes |
| **Staff** | person allowed into the app | Yes – this is how you give or remove access |
| **Invoices** | invoice, draft or opening balance | **Use the app.** Sheets warns before editing |
| **InvoiceLines** | itemised charge or adjustment | **Use the app** |
| **Payments** | payment received | **Use the app** |
| **Allocations** | part of a payment applied to an invoice | **Use the app** |
| **Credits** | credit adjustment | **Use the app** |
| **EmailLog** | email sent, attempted or skipped | Read only |
| **Audit** | change: who, when, what | Read only |
| **Invoice balances** | invoice, with paid, credited, balance and status | Read only – rebuilt automatically after every change |

The tabs marked *use the app* are protected with a warning, not a lock. Editing them by hand would skip the duplicate checks and the audit trail. If you need to correct something, use void and reissue, a credit adjustment, or a payment correction or reversal in the app; each is recorded with who did it.

**Reports beyond the app:** the *Invoice balances* tab is ready-made for pivot tables (**Insert → Pivot table**), charts, or connecting to Looker Studio. The app's **Export CSV** buttons give the same data as files.

## 4. Emails and automatic reminders

- **Recipients and preview:** each email goes to one account's billing officer, plus that account's CC if set, and never mixes accounts. The preview shows the exact To and CC addresses, subject, attachment and current balance before you send. If a payment is recorded between preview and send, the send is refused and you're asked to look again.
- **Timing:** reminder timing is days from the due date, `-7, 7, 14` by default. That's a friendly reminder a week before, then your overdue wording a week after and two weeks after.
- **Hourly check:** every hour, the timer checks each issued invoice and skips any that are paid, void, belong to a paused account, or whose account has no email. If several stages were missed, it sends only the latest. It writes the stage to the EmailLog **before** sending, and the whole run holds a lock, so it can never send the same stage twice. It re-reads the balance immediately before handing the email to Gmail, so the email always shows the **current amount outstanding**, including after a partial payment.
- **The log:** the EmailLog tab records the recipients, the time, *Accepted by Gmail for delivery* or the exact error, and the balance shown. A failed send (for example, the daily limit reached) is retried on the next hourly run.

## 5. Backups and restoring

There are three layers. All of them are in your Google account.

1. **Version history (undo mistakes).** In the Sheet, open **File → Version history → See version history**. Pick a time before the mistake and click **Restore this version**. Use this for something like an accidental deletion.
2. **Weekly copies.** Every week a full copy of the spreadsheet is saved to *MTC Billing – Backups* in Drive, and the latest 12 copies (about three months) are kept. **MTC Billing → Back up now** makes one immediately, for example before a big change.
3. **PDFs and evidence.** These stay in their Drive folders. If one is deleted, it sits in Drive's **Bin** for 30 days, where **Restore** puts it back.

**Restoring from a weekly copy:**
- *A few records:* open the backup copy, copy the rows you need, and paste them into the live Sheet.
- *Everything:* the live Sheet is badly damaged, so make the backup the live one. Open the backup copy, then **Extensions → Apps Script → Deploy → New deployment** as in step 8. Run `setup` once from that copy's editor, which reinstalls the timers. Use the new web app URL, and rename or archive the old Sheet so nobody uses it by mistake.

A backup copy contains customer and bank details. Keep the Backups folder private.

## 6. Updating the app

If you receive updated files, paste them over the old ones (or run `clasp push`). Then go to **Deploy → Manage deployments → ✏️ Edit**, set **Version: New version**, and click **Deploy**. The link stays the same. Afterwards, run `setup` once. It only adds what's missing and never deletes data.

## 7. How the billing rules work

The rules are identical to the server version.

**Quarters.** Q1 is January–March, Q2 April–June, Q3 July–September and Q4 October–December. Each account can have only one live invoice per quarter. Running *Create drafts* again skips accounts that already have one and lists them as skipped. Voiding an invoice frees the quarter for its replacement.

**Custom periods** are for exceptions. If one overlaps an existing invoice, the app shows the overlap and asks you to confirm before creating it.

**Charges** follow each kit's billing start and end dates and the rate in force on each day:
- Whole calendar months at the same rate are combined into one line.
- Part months, such as a mid-month start or end or a mid-month rate change, are worked out by day. They must be confirmed before issue, and any change needs a reason.
- Suspended kits aren't billed.
- A kit with no rate for part of the period blocks the invoice from being issued.

**Rate changes** are added with a start date, so earlier periods keep the old rate. Issued invoices never change. Drafts update when you press **Recalculate charges**.

**Adjustments** on a draft are an extra charge or a discount, with a reason that is printed on the invoice.

**Due date.** Leave it blank to use the invoice date plus the default days, or set a date.

**Issuing.** Issuing assigns the next number, sets today's date and saves the PDF in Drive. You can issue one draft at a time or tick several on the Invoices page. Issued invoices can't be edited.

**Corrections** to issued invoices:
- **Credit adjustment:** a numbered credit (`MTC-CR-0001`) with a reason.
- **Void (and reissue):** marks the invoice void with a reason; it stays in the history. Any payments on it go back to the account's credit, and a replacement draft is created for you to issue.

**Payments.**
- Record the amount, date, payer, reference, method, notes and an optional proof file.
- Apply the payment oldest invoices first, by amounts you enter, or keep it as credit. One payment can cover several invoices.
- Anything left over shows as the account's credit until you apply it.
- A payment is flagged as a possible duplicate if it has the same reference as an existing payment, or the same account and amount within 3 days.
- Corrections, reversals and unapplying are all in the audit trail.
- Everything is checked **before** anything is written, so a mistake never leaves a half-saved payment.

**Balances and status.**
- Balance = invoice total − payments applied − credits.
- Status is *Unpaid*, *Partly paid* or *Paid*. *Overdue* is shown separately when a balance remains after the due date.

**Statements** list invoices, credits and payments in date order with a running balance, with optional dates and **Print**.

**Dashboard and Follow-ups.** The dashboard shows the selected quarter's billed, applied, outstanding and overdue totals. Follow-ups lists overdue accounts with their officer, how long they've been overdue, when they were last emailed, and the next automatic reminder.

## 8. What was tested, and what to check yourself

Google's servers can't be reached from where this was built, so the code was tested against realistic stand-ins for Sheets, Drive, Gmail, locks and timers. The Sheets stand-in behaves like the real thing in the ways that matter here. It turns number-like text into numbers and date-like text into dates, and it rejects anything that would become a formula, so the tests prove the app keeps your data exactly as typed.

`node tests/run_tests.js` runs **12 tests, all passing**. They include your required example:
- A AUD 300 quarterly invoice is issued, and its PDF contents are checked.
- A AUD 100 payment is recorded. The invoice, the statement, the reminder preview and the automatic reminder email all show **AUD 200.00 outstanding**. The email goes to the officer with the CC copied, in your overdue wording, with the PDF attached.
- Running reminders again sends nothing new.
- A duplicate-looking payment is caught.
- The remaining AUD 200 is recorded. The invoice is **Paid**, and the 14-day reminder does **not** send.
- Rerunning quarterly generation creates **no duplicate**.

The other tests cover:
- part months and a mid-month rate change;
- overlap warnings, and void and reissue;
- a split payment and its reversal;
- failed-email retry;
- staff-only access and private evidence storage;
- text kept exactly as typed (leading zeros, dates, no formulas);
- edits made directly in the Sheet being picked up;
- backups and the warnings on protected tabs.

`tests/ui_flow.py` also clicks through the whole example in a real browser, using the actual pages, with no script errors.

**What only Google can show, so please check on first use:**
- **The PDF's look.** Google's own converter makes the PDF, so the layout can differ slightly from the preview. The wording and figures are set by the app.
- **A real email.** Send the test invoice to yourself (step 2.5) and check the subject, attachment and wording.
- **Downloads in your browser.** Check that PDF and CSV downloads work on the computers and phones you use. If a download button does nothing, the PDF is always in *MTC Billing – Invoice PDFs* in your Drive.

## 9. Limits to know about

- **Speed:** each action takes about 1–3 seconds, because Google runs the code on request. The page itself loads once and then only exchanges small amounts of data, which suits slower connections.
- **Gmail:** Workspace accounts can send to about 1,500 recipients a day through Apps Script, and the app shows the remaining amount. *Accepted by Gmail* means Gmail took the message. If an address bounces, the bounce arrives in the sending account's inbox.
- **Sign-in:** staff must use accounts in your Google Workspace organisation. Personal Gmail accounts can't open the app with these settings.
- **Size:** the Sheet holds years of records for 13 accounts comfortably. Google allows 10 million cells per spreadsheet.
